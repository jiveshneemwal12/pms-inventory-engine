from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # Admin
    path("admin/", admin.site.urls),
    
    # Authentication
    path("api/auth/", include("apps.authn.urls")),
    
    # Properties
    path("api/properties/", include("apps.properties.urls")),
    
    # Inventory
    path("api/inventory/", include("apps.inventory.urls")),
    
    # # App URLs
    # path("api/reservations/", include("apps.reservations.urls")),
]
