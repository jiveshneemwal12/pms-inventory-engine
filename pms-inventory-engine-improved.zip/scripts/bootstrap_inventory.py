#!/usr/bin/env python
"""
Bootstrap script to preload inventory for all room types.
Usage: python scripts/bootstrap_inventory.py
"""
import os
import sys
import django
from datetime import date, timedelta

# Setup Django
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pms_backend.settings')
django.setup()

from apps.properties.models import Property, RoomType
from apps.inventory.services import InventoryService


def bootstrap_inventory():
    """
    Bootstrap inventory calendar for all room types.
    Preloads 365 days of inventory starting from today.
    """
    print("=" * 80)
    print("INVENTORY BOOTSTRAP SCRIPT")
    print("=" * 80)
    
    start_date = date.today()
    days = 365
    
    print(f"\nPreloading inventory from {start_date} for {days} days...")
    print(f"End date: {start_date + timedelta(days=days)}\n")
    
    # Get all room types
    room_types = RoomType.objects.select_related('property').all()
    
    if not room_types.exists():
        print("⚠️  No room types found. Please create properties and room types first.")
        print("\nSteps:")
        print("1. Create a superuser: python manage.py createsuperuser")
        print("2. Run server: python manage.py runserver")
        print("3. Go to http://localhost:8000/admin")
        print("4. Create Properties and Room Types")
        print("5. Run this script again")
        return
    
    print(f"Found {room_types.count()} room type(s):\n")
    
    for room_type in room_types:
        print(f"📍 {room_type.property.name} - {room_type.name}")
        print(f"   Total units: {room_type.total_units}")
        
        try:
            # Preload inventory
            InventoryService.preload_inventory(room_type, start_date, days)
            print(f"   ✅ Successfully preloaded {days} days of inventory\n")
        except Exception as e:
            print(f"   ❌ Error: {str(e)}\n")
    
    print("=" * 80)
    print("BOOTSTRAP COMPLETE")
    print("=" * 80)
    print("\nNext steps:")
    print("1. Check inventory in admin: http://localhost:8000/admin/inventory/inventorycalendar/")
    print("2. Test availability API: POST /inventory/check/")
    print("3. Create test reservations: POST /reservations/create/")


if __name__ == '__main__':
    bootstrap_inventory()
