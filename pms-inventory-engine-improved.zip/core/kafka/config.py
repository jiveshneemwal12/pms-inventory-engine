"""
Kafka configuration settings.
"""

KAFKA_BOOTSTRAP_SERVERS = "localhost:9092"

KAFKA_TOPICS = {
    "PMS_EVENTS": "pms-events",
    "INVENTORY_UPDATED": "pms.inventory.updated",
    "RESERVATION_CREATED": "pms.reservation.created",
    "RESERVATION_CANCELLED": "pms.reservation.cancelled",
}
