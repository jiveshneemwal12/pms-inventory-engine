"""
Utility script to create Kafka topics.

Run this before starting the consumer:
    python -m core.kafka.create_topics
"""
from confluent_kafka.admin import AdminClient, NewTopic
from core.kafka.config import KAFKA_BOOTSTRAP_SERVERS, KAFKA_TOPICS


def create_topics():
    """
    Create all Kafka topics defined in config.
    """
    admin_client = AdminClient({
        "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS
    })
    
    # List of topics to create
    topics_to_create = []
    for topic_key, topic_name in KAFKA_TOPICS.items():
        new_topic = NewTopic(
            topic=topic_name,
            num_partitions=3,  # Number of partitions
            replication_factor=1  # Replication factor (1 for single broker)
        )
        topics_to_create.append(new_topic)
    
    print(f"Creating {len(topics_to_create)} topics...")
    
    # Create topics
    futures = admin_client.create_topics(topics_to_create)
    
    # Wait for operation to finish
    for topic_name, future in futures.items():
        try:
            future.result()  # The result itself is None
            print(f"✓ Topic '{topic_name}' created successfully")
        except Exception as e:
            if "TOPIC_ALREADY_EXISTS" in str(e):
                print(f"✓ Topic '{topic_name}' already exists")
            else:
                print(f"✗ Failed to create topic '{topic_name}': {e}")


if __name__ == "__main__":
    create_topics()
    print("\nAll topics are ready!")
