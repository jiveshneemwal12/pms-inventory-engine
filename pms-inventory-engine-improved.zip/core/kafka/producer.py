"""
Kafka producer for publishing events asynchronously.
"""
from confluent_kafka import Producer
import json
from core.kafka.config import KAFKA_BOOTSTRAP_SERVERS


# Initialize Kafka producer
producer = Producer({
    "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
    "allow.auto.create.topics": True,  # Auto-create topics if they don't exist
    "acks": "all",  # Wait for all replicas to acknowledge
})


def delivery_report(err, msg):
    """
    Callback for producer delivery reports.
    Called once for each message produced to indicate delivery result.
    """
    if err:
        print(f"Message delivery failed: {err}")
    else:
        print(f"Message delivered to {msg.topic()} [{msg.partition()}]")


def publish_event(topic: str, payload: dict):
    """
    Publish an event to Kafka topic.
    
    Args:
        topic (str): Kafka topic name
        payload (dict): Event data to publish
    """
    try:
        producer.produce(
            topic=topic,
            value=json.dumps(payload).encode("utf-8"),
            callback=delivery_report,
        )
        # Trigger delivery report callbacks
        producer.poll(0)
    except Exception as e:
        print(f"Failed to publish event: {e}")


def flush_producer():
    """
    Wait for all messages in the producer queue to be delivered.
    Call this before shutting down the application.
    """
    producer.flush()
