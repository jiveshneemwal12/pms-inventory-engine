"""
Kafka consumer for processing events in the background.

Run this as a separate service:
    python -m core.kafka.consumer
"""
from confluent_kafka import Consumer, KafkaError
import json
import time
from core.kafka.config import KAFKA_BOOTSTRAP_SERVERS


def create_consumer(group_id="pms-consumer-group"):
    """
    Create and configure a Kafka consumer.
    
    Args:
        group_id (str): Consumer group ID
        
    Returns:
        Consumer: Configured Kafka consumer instance
    """
    consumer = Consumer({
        "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
        "group.id": group_id,
        "auto.offset.reset": "earliest",
        "enable.auto.commit": True,
        "allow.auto.create.topics": True,  # Auto-create topics if they don't exist
    })
    return consumer


def process_event(event_data: dict):
    """
    Process a single event from Kafka.
    Add your business logic here.
    
    Args:
        event_data (dict): The event payload
    """
    event_type = event_data.get("event")
    
    if event_type == "PROJECT_CREATED":
        print(f"Processing project creation: {event_data}")
        # Add your logic here (e.g., send notifications, update cache, etc.)
    
    elif event_type == "INVENTORY_UPDATED":
        print(f"Processing inventory update: {event_data}")
        # Add your logic here
    
    elif event_type == "RESERVATION_CREATED":
        print(f"Processing reservation creation: {event_data}")
        # Add your logic here
    
    elif event_type == "RESERVATION_CANCELLED":
        print(f"Processing reservation cancellation: {event_data}")
        # Add your logic here
    
    else:
        print(f"Unknown event type: {event_type}")


def start_consumer(topics=None):
    """
    Start the Kafka consumer and process messages.
    
    Args:
        topics (list): List of topics to subscribe to
    """
    if topics is None:
        topics = ["pms-events"]
    
    consumer = create_consumer()
    consumer.subscribe(topics)
    
    print(f"Kafka consumer started. Listening to topics: {topics}")
    
    try:
        while True:
            msg = consumer.poll(timeout=1.0)
            
            if msg is None:
                continue
            
            if msg.error():
                if msg.error().code() == KafkaError._PARTITION_EOF:
                    # End of partition event
                    print(f"Reached end of partition {msg.partition()}")
                else:
                    print(f"Consumer error: {msg.error()}")
                continue
            
            # Decode and process the message
            try:
                data = json.loads(msg.value().decode("utf-8"))
                print(f"Received event: {data}")
                process_event(data)
            except json.JSONDecodeError as e:
                print(f"Failed to decode message: {e}")
            except Exception as e:
                print(f"Error processing event: {e}")
    
    except KeyboardInterrupt:
        print("Consumer interrupted by user")
    
    finally:
        consumer.close()
        print("Consumer closed")


if __name__ == "__main__":
    # Start consuming messages
    start_consumer(topics=["pms-events"])
