"""
Common app - Shared utilities only.
"""
