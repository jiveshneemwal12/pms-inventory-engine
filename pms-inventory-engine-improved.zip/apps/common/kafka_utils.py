"""
Kafka utilities for event publishing.
"""
from kafka import KafkaProducer
from django.conf import settings


_producer = None


def get_producer():
    """
    Get or create Kafka producer instance (singleton).
    
    Returns:
        KafkaProducer instance
    """
    global _producer
    
    if _producer is None:
        _producer = KafkaProducer(
            bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
            # Add other configurations as needed
        )
    
    return _producer


def close_producer():
    """Close the Kafka producer connection."""
    global _producer
    
    if _producer is not None:
        _producer.close()
        _producer = None
