"""
Email utility functions for sending plain text and HTML emails.
"""
from django.core.mail import send_mail, EmailMultiAlternatives
from django.template.loader import get_template, render_to_string
from django.utils.html import strip_tags
from django.conf import settings

import logging

logger = logging.getLogger(__name__)


def send_email(subject, template_name, data, to, from_email=None, message=None):
    """
    Send a plain text email.
    
    Args:
        subject: Email subject
        template_name: Template file path
        data: Context data for template
        to: List of recipient emails
        from_email: Sender email (optional)
        message: Pre-rendered message (optional)
    """
    try:
        template = get_template(template_name)
        content = message or template.render(data)
        
        send_mail(
            subject=subject,
            message=content,
            from_email=from_email or settings.DEFAULT_FROM_EMAIL,
            recipient_list=to
        )
        logger.info(f"Email sent to {to}")
    except Exception as e:
        logger.error(f"Error sending email to {to}: {repr(e)}")


def send_html_email(subject, template_name, data, to, from_email=None, message=None):
    """
    Send an HTML email with plain text fallback.
    
    Args:
        subject: Email subject
        template_name: HTML template file path
        data: Context data for template
        to: List of recipient emails
        from_email: Sender email (optional)
        message: Pre-rendered HTML message (optional)
    """
    try:
        html_content = message or render_to_string(template_name, data)
        text_content = strip_tags(html_content)
        
        email = EmailMultiAlternatives(
            subject=subject,
            body=text_content,
            from_email=from_email or settings.DEFAULT_FROM_EMAIL,
            to=to
        )
        email.attach_alternative(html_content, "text/html")
        email.send()
        logger.info(f"HTML email sent to {to}")
    except Exception as e:
        logger.error(f"Error sending HTML email to {to}: {repr(e)}")
