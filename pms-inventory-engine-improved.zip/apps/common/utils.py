"""
Common utility functions.
"""
import string
import random
import logging

logger = logging.getLogger(__name__)


def generate_random_password(length=12):
    """
    Generate a random password with letters, digits and special characters.
    """
    characters = string.ascii_letters + string.digits + "!@#$%^&*"
    password = ''.join(random.choice(characters) for _ in range(length))
    return password


def send_login_details(user_data, password):
    """
    Send login details via email (stub implementation).
    In production, integrate with email service provider.
    """
    try:
        # TODO: Implement actual email sending logic
        # Example: using SendGrid, AWS SES, or SMTP
        logger.info(f"Sending login details to {user_data.get('email')}")
        logger.info(f"Temporary password: {password}")
        
        # Placeholder for email sending
        # send_email(
        #     to=user_data.get('email'),
        #     subject='Your Login Credentials',
        #     body=f'Your password is: {password}'
        # )
        
    except Exception as e:
        logger.error(f"Failed to send login details: {str(e)}")


def send_password_reset_email(user_email, reset_token):
    """
    Send password reset email with token (stub implementation).
    In production, integrate with email service provider.
    """
    try:
        # TODO: Implement actual email sending logic
        logger.info(f"Sending password reset email to {user_email}")
        logger.info(f"Reset token: {reset_token}")
        
        # Placeholder for email sending
        # send_email(
        #     to=user_email,
        #     subject='Password Reset Request',
        #     body=f'Reset token: {reset_token}'
        # )
        
    except Exception as e:
        logger.error(f"Failed to send password reset email: {str(e)}")
