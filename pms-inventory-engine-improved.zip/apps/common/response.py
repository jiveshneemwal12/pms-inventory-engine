"""
Common response utilities.
"""
from rest_framework.response import Response
from rest_framework import status


def create_response(status_type, message, data=None, errors=None, http_status=status.HTTP_200_OK):
    """
    Create a standardized API response.
    
    Args:
        status_type: 'success' or 'failed'
        message: Response message
        data: Response data (optional)
        errors: Error details (optional)
        http_status: HTTP status code
    
    Returns:
        Response object with standardized structure
    """
    response_data = {
        'status': status_type,
        'message': message,
    }
    
    if data is not None:
        response_data['data'] = data
    
    if errors is not None:
        response_data['errors'] = errors
    
    return Response(response_data, status=http_status)
