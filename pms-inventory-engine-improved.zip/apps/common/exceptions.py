"""
Custom exceptions for the PMS backend.
"""


class PMSException(Exception):
    """Base exception for PMS."""
    pass


class InsufficientInventoryException(PMSException):
    """Raised when there's not enough inventory available."""
    pass


class InventoryLockException(PMSException):
    """Raised when inventory cannot be locked."""
    pass


class InvalidReservationException(PMSException):
    """Raised when reservation data is invalid."""
    pass


class ReservationNotFoundException(PMSException):
    """Raised when a reservation cannot be found."""
    pass
