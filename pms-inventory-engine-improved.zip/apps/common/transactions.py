"""
Database transaction helpers.
"""
from django.db import transaction
from functools import wraps


def atomic_transaction(func):
    """
    Decorator to wrap a function in an atomic transaction.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        with transaction.atomic():
            return func(*args, **kwargs)
    return wrapper


def select_for_update_nowait(queryset):
    """
    Helper to add select_for_update with nowait to a queryset.
    """
    return queryset.select_for_update(nowait=True)
