"""
Kafka producer for event publishing.
IMPORTANT: Publishing happens AFTER DB COMMIT ONLY.
"""
import json
import logging
from django.conf import settings

logger = logging.getLogger(__name__)


class EventProducer:
    """
    Kafka event producer.
    Note: This is a stub implementation. In production, use kafka-python or confluent-kafka.
    """
    
    def __init__(self):
        self.bootstrap_servers = settings.KAFKA_BOOTSTRAP_SERVERS
        self.topics = settings.KAFKA_TOPICS
        # In production: initialize KafkaProducer here
        # self.producer = KafkaProducer(
        #     bootstrap_servers=self.bootstrap_servers,
        #     value_serializer=lambda v: json.dumps(v).encode('utf-8')
        # )
    
    def publish(self, topic_key, event_schema):
        """
        Publish an event to Kafka.
        
        Args:
            topic_key: Key from KAFKA_TOPICS (e.g., 'INVENTORY_UPDATED')
            event_schema: Event schema instance (e.g., InventoryUpdatedEvent)
        
        CRITICAL: Only call this AFTER database transaction commits.
        """
        topic = self.topics.get(topic_key)
        if not topic:
            logger.error(f"Topic key '{topic_key}' not found in KAFKA_TOPICS")
            return
        
        try:
            event_data = event_schema.to_dict()
            
            # Production implementation:
            # future = self.producer.send(topic, value=event_data)
            # future.get(timeout=10)  # Wait for acknowledgment
            
            # Stub implementation for development:
            logger.info(f"[KAFKA STUB] Publishing to {topic}: {event_data}")
            
        except Exception as e:
            logger.error(f"Failed to publish event to {topic}: {str(e)}")
    
    def close(self):
        """Close the producer connection."""
        # Production: self.producer.close()
        pass


# Singleton instance
_producer = None


def get_producer():
    """Get or create the event producer singleton."""
    global _producer
    if _producer is None:
        _producer = EventProducer()
    return _producer
