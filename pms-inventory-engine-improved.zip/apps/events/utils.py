"""
Utility to publish events after transaction commits.
"""
from django.db import transaction


def publish_after_commit(topic_key, event_schema):
    """
    Publish an event after the current transaction commits.
    
    Args:
        topic_key: Kafka topic key
        event_schema: Event schema instance
    """
    from .producer import get_producer
    
    def on_commit():
        producer = get_producer()
        producer.publish(topic_key, event_schema)
    
    transaction.on_commit(on_commit)
