"""
Events app - Event publishing only (Kafka).
"""
