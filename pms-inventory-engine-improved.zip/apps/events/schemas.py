"""
Event schemas for publishing.
"""
from datetime import datetime
import json


class BaseEventSchema:
    """Base event schema."""
    
    def __init__(self, event_type, data):
        self.event_type = event_type
        self.timestamp = datetime.utcnow().isoformat()
        self.data = data
    
    def to_dict(self):
        return {
            'event_type': self.event_type,
            'timestamp': self.timestamp,
            'data': self.data
        }
    
    def to_json(self):
        return json.dumps(self.to_dict())


class InventoryUpdatedEvent(BaseEventSchema):
    """Event for inventory updates."""
    
    def __init__(self, room_type_id, date, available_units):
        data = {
            'room_type_id': str(room_type_id),
            'date': str(date),
            'available_units': available_units
        }
        super().__init__('inventory.updated', data)


class ReservationCreatedEvent(BaseEventSchema):
    """Event for new reservations."""
    
    def __init__(self, reservation):
        data = {
            'reservation_id': str(reservation.id),
            'property_id': str(reservation.property.id),
            'check_in': str(reservation.check_in),
            'check_out': str(reservation.check_out),
            'status': reservation.status,
            'guest_email': reservation.guest_email,
        }
        super().__init__('reservation.created', data)


class ReservationCancelledEvent(BaseEventSchema):
    """Event for cancelled reservations."""
    
    def __init__(self, reservation):
        data = {
            'reservation_id': str(reservation.id),
            'property_id': str(reservation.property.id),
            'check_in': str(reservation.check_in),
            'check_out': str(reservation.check_out),
            'cancelled_at': datetime.utcnow().isoformat(),
        }
        super().__init__('reservation.cancelled', data)
