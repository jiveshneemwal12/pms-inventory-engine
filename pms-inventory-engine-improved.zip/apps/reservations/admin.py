from django.contrib import admin
from .models import Reservation, ReservationRoom


class ReservationRoomInline(admin.TabularInline):
    model = ReservationRoom
    extra = 0


@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ('guest_name', 'property', 'check_in', 'check_out', 'status', 'source', 'created_at')
    list_filter = ('status', 'source', 'property', 'check_in')
    search_fields = ('guest_name', 'guest_email', 'guest_phone')
    date_hierarchy = 'check_in'
    inlines = [ReservationRoomInline]
    readonly_fields = ('created_at', 'updated_at')
