"""
Reservation service layer - Booking transactions.
"""
from django.db import transaction
from apps.common.exceptions import InsufficientInventoryException, InvalidReservationException
from apps.inventory.services import InventoryService
from .models import Reservation, ReservationRoom


class ReservationService:
    """
    Service for managing reservation operations.
    MUST use transactions and coordinate with InventoryService.
    """
    
    @staticmethod
    @transaction.atomic
    def create_booking(property, check_in, check_out, rooms_data, guest_data, source='DIRECT', idempotency_key=None):
        """
        Create a new booking with inventory reservation.
        Implements Idempotency and Event Sourcing principles.
        
        Args:
            property: Property instance
            check_in: datetime.date
            check_out: datetime.date
            rooms_data: list of dicts [{'room_type': RoomType, 'quantity': int}, ...]
            guest_data: dict with guest_name, guest_email, guest_phone
            source: str - booking source
            idempotency_key: str - for safe retries (optional)
            
        Returns:
            Reservation instance
            
        Raises:
            InsufficientInventoryException: If not enough inventory
            InvalidReservationException: If data is invalid
        
        Design Principles Applied:
        1. Single Responsibility - Only handles booking creation
        2. Event Sourcing - Inventory changes via events
        3. Idempotency - Safe retry with idempotency_key
        4. Optimistic Locking - Via InventoryService
        """
        import uuid
        
        # Validate dates
        if check_in >= check_out:
            raise InvalidReservationException("Check-out must be after check-in")
        
        if not rooms_data:
            raise InvalidReservationException("At least one room must be specified")
        
        # Generate correlation_id for all related inventory events
        correlation_id = uuid.uuid4()
        
        # Check if this is a retry (idempotency check)
        if idempotency_key:
            existing = Reservation.objects.filter(
                property=property,
                check_in=check_in,
                check_out=check_out,
                guest_email=guest_data['guest_email'],
                status__in=['PENDING', 'CONFIRMED']
            ).first()
            if existing:
                return existing  # Return existing reservation (idempotent)
        
        # Check availability for all rooms (read-only)
        for room_data in rooms_data:
            room_type = room_data['room_type']
            quantity = room_data['quantity']
            
            if not InventoryService.check_availability(
                room_type, check_in, check_out, quantity
            ):
                raise InsufficientInventoryException(
                    f"Insufficient inventory for {room_type.name}"
                )
        
        # Create reservation first
        reservation = Reservation.objects.create(
            property=property,
            check_in=check_in,
            check_out=check_out,
            source=source,
            status='CONFIRMED',
            guest_name=guest_data['guest_name'],
            guest_email=guest_data['guest_email'],
            guest_phone=guest_data.get('guest_phone', ''),
        )
        
        # Reserve inventory with Event Sourcing
        # Each room type reservation uses the same correlation_id
        for room_data in rooms_data:
            InventoryService.reserve(
                room_data['room_type'],
                check_in,
                check_out,
                room_data['quantity'],
                correlation_id=correlation_id,
                reservation_id=reservation.id,
                triggered_by=f"reservation:{reservation.id}"
            )
        
        # Create reservation rooms
        for room_data in rooms_data:
            ReservationRoom.objects.create(
                reservation=reservation,
                room_type=room_data['room_type'],
                quantity=room_data['quantity']
            )
        
        return reservation
    
    @staticmethod
    @transaction.atomic
    def cancel_booking(reservation, idempotency_key=None):
        """
        Cancel a booking and release inventory.
        Implements Idempotency and Event Sourcing principles.
        
        Args:
            reservation: Reservation instance
            idempotency_key: str - for safe retries (optional)
            
        Returns:
            Reservation instance
            
        Design Principles Applied:
        1. Single Responsibility - Only handles cancellation
        2. Event Sourcing - Inventory release via events
        3. Idempotency - Safe retry (already cancelled = success)
        4. Optimistic Locking - Via InventoryService
        """
        import uuid
        
        # Idempotency: If already cancelled, return success
        if reservation.status == 'CANCELLED':
            return reservation
        
        if reservation.status == 'CHECKED_OUT':
            raise InvalidReservationException("Cannot cancel checked-out reservation")
        
        # Generate correlation_id for all related inventory events
        correlation_id = uuid.uuid4()
        
        # Release inventory for all rooms with Event Sourcing
        for reservation_room in reservation.rooms.all():
            InventoryService.release(
                reservation_room.room_type,
                reservation.check_in,
                reservation.check_out,
                reservation_room.quantity,
                correlation_id=correlation_id,
                reservation_id=reservation.id,
                triggered_by=f"cancellation:{reservation.id}"
            )
        
        # Update reservation status
        reservation.status = 'CANCELLED'
        reservation.save(update_fields=['status', 'updated_at'])
        
        return reservation
