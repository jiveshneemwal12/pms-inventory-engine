"""
Serializers for reservations.
"""
from rest_framework import serializers
from .models import Reservation, ReservationRoom


class ReservationRoomSerializer(serializers.ModelSerializer):
    room_type_name = serializers.CharField(source='room_type.name', read_only=True)
    
    class Meta:
        model = ReservationRoom
        fields = ('id', 'room_type', 'room_type_name', 'quantity')
        read_only_fields = ('id',)


class ReservationSerializer(serializers.ModelSerializer):
    rooms = ReservationRoomSerializer(many=True, read_only=True)
    property_name = serializers.CharField(source='property.name', read_only=True)
    
    class Meta:
        model = Reservation
        fields = (
            'id', 'property', 'property_name', 'status', 'check_in', 'check_out',
            'source', 'guest_name', 'guest_email', 'guest_phone',
            'total_amount', 'notes', 'rooms', 'created_at', 'updated_at'
        )
        read_only_fields = ('id', 'created_at', 'updated_at')
