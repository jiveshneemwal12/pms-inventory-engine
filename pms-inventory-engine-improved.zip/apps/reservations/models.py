"""
Reservation and ReservationRoom models.
"""
from django.db import models
from apps.common.models import UUIDModel, TimeStampedModel
from apps.properties.models import Property, RoomType


class Reservation(UUIDModel, TimeStampedModel):
    """
    Main reservation/booking model.
    """
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('CONFIRMED', 'Confirmed'),
        ('CHECKED_IN', 'Checked In'),
        ('CHECKED_OUT', 'Checked Out'),
        ('CANCELLED', 'Cancelled'),
    ]
    
    SOURCE_CHOICES = [
        ('DIRECT', 'Direct'),
        ('BOOKING_COM', 'Booking.com'),
        ('AIRBNB', 'Airbnb'),
        ('EXPEDIA', 'Expedia'),
        ('OTHER', 'Other'),
    ]
    
    property = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='reservations'
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='PENDING'
    )
    check_in = models.DateField(db_index=True)
    check_out = models.DateField(db_index=True)
    source = models.CharField(
        max_length=30,
        choices=SOURCE_CHOICES,
        default='DIRECT'
    )
    
    guest_name = models.CharField(max_length=255)
    guest_email = models.EmailField()
    guest_phone = models.CharField(max_length=20, blank=True)
    
    total_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0
    )
    
    notes = models.TextField(blank=True)
    
    class Meta:
        db_table = 'reservations'
        verbose_name = 'Reservation'
        verbose_name_plural = 'Reservations'
        indexes = [
            models.Index(fields=['property', 'check_in']),
            models.Index(fields=['property', 'check_out']),
            models.Index(fields=['status']),
        ]
    
    def __str__(self):
        return f"{self.guest_name} - {self.check_in} to {self.check_out}"


class ReservationRoom(UUIDModel):
    """
    Room allocation for a reservation.
    Links reservation to specific room types and quantities.
    """
    reservation = models.ForeignKey(
        Reservation,
        on_delete=models.CASCADE,
        related_name='rooms'
    )
    room_type = models.ForeignKey(
        RoomType,
        on_delete=models.CASCADE
    )
    quantity = models.PositiveIntegerField(default=1)
    
    class Meta:
        db_table = 'reservation_rooms'
        verbose_name = 'Reservation Room'
        verbose_name_plural = 'Reservation Rooms'
    
    def __str__(self):
        return f"{self.reservation} - {self.room_type} x{self.quantity}"
