"""
Reservation API views.
"""
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from datetime import datetime
from apps.properties.models import Property, RoomType
from apps.common.exceptions import InsufficientInventoryException, InvalidReservationException
from .services import ReservationService
from .serializers import ReservationSerializer


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_reservation(request):
    """
    Create a new reservation (SYNC).
    
    POST /reservations/create
    {
        "property_id": "uuid",
        "check_in": "2025-01-01",
        "check_out": "2025-01-05",
        "rooms": [
            {"room_type_id": "uuid", "quantity": 2}
        ],
        "guest": {
            "name": "John Doe",
            "email": "john@example.com",
            "phone": "+1234567890"
        },
        "source": "DIRECT"
    }
    """
    try:
        property_id = request.data.get('property_id')
        check_in = datetime.strptime(request.data.get('check_in'), '%Y-%m-%d').date()
        check_out = datetime.strptime(request.data.get('check_out'), '%Y-%m-%d').date()
        rooms_input = request.data.get('rooms', [])
        guest_data = request.data.get('guest', {})
        source = request.data.get('source', 'DIRECT')
        
        # Validate input
        property = Property.objects.get(id=property_id)
        
        # Build rooms data
        rooms_data = []
        for room_input in rooms_input:
            room_type = RoomType.objects.get(id=room_input['room_type_id'])
            rooms_data.append({
                'room_type': room_type,
                'quantity': room_input['quantity']
            })
        
        guest_info = {
            'guest_name': guest_data.get('name'),
            'guest_email': guest_data.get('email'),
            'guest_phone': guest_data.get('phone', ''),
        }
        
        # Create booking
        reservation = ReservationService.create_booking(
            property=property,
            check_in=check_in,
            check_out=check_out,
            rooms_data=rooms_data,
            guest_data=guest_info,
            source=source
        )
        
        # TODO: Publish event AFTER transaction commits
        # EventProducer.publish('pms.reservation.created', reservation_data)
        
        serializer = ReservationSerializer(reservation)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
        
    except (Property.DoesNotExist, RoomType.DoesNotExist) as e:
        return Response(
            {'error': str(e)},
            status=status.HTTP_404_NOT_FOUND
        )
    except (InsufficientInventoryException, InvalidReservationException) as e:
        return Response(
            {'error': str(e)},
            status=status.HTTP_400_BAD_REQUEST
        )
    except Exception as e:
        return Response(
            {'error': str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def cancel_reservation(request, reservation_id):
    """
    Cancel a reservation (SYNC).
    
    POST /reservations/{id}/cancel
    """
    try:
        from .models import Reservation
        reservation = Reservation.objects.get(id=reservation_id)
        
        cancelled_reservation = ReservationService.cancel_booking(reservation)
        
        # TODO: Publish event AFTER transaction commits
        # EventProducer.publish('pms.reservation.cancelled', reservation_data)
        
        serializer = ReservationSerializer(cancelled_reservation)
        return Response(serializer.data)
        
    except Reservation.DoesNotExist:
        return Response(
            {'error': 'Reservation not found'},
            status=status.HTTP_404_NOT_FOUND
        )
    except InvalidReservationException as e:
        return Response(
            {'error': str(e)},
            status=status.HTTP_400_BAD_REQUEST
        )
    except Exception as e:
        return Response(
            {'error': str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
