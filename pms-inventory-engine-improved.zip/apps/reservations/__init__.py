"""
Reservations app - Booking lifecycle.
"""
