"""
Kafka event schemas for properties management.
"""
from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass
class PropertyCreatedEvent:
    """Event published when a new property is created"""
    property_id: str
    property_code: str
    property_name: str
    timezone: str
    status: str
    city: str
    country: str
    created_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> dict[str, Any]:
        return {
            'property_id': self.property_id,
            'property_code': self.property_code,
            'property_name': self.property_name,
            'timezone': self.timezone,
            'status': self.status,
            'city': self.city,
            'country': self.country,
            'created_by': self.created_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class PropertyUpdatedEvent:
    """Event published when a property is updated"""
    property_id: str
    property_code: str
    changes: dict[str, Any]
    updated_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> dict[str, Any]:
        return {
            'property_id': self.property_id,
            'property_code': self.property_code,
            'changes': self.changes,
            'updated_by': self.updated_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class PropertyStatusChangedEvent:
    """Event published when property status changes"""
    property_id: str
    property_code: str
    old_status: str
    new_status: str
    changed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> dict[str, Any]:
        return {
            'property_id': self.property_id,
            'property_code': self.property_code,
            'old_status': self.old_status,
            'new_status': self.new_status,
            'changed_by': self.changed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class PropertyDeletedEvent:
    """Event published when a property is deleted"""
    property_id: str
    property_code: str
    deleted_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> dict[str, Any]:
        return {
            'property_id': self.property_id,
            'property_code': self.property_code,
            'deleted_by': self.deleted_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class RoomTypeCreatedEvent:
    """Event published when a new room type is created"""
    roomtype_id: str
    property_id: str
    property_code: str
    room_type_code: str
    room_type_name: str
    base_physical_count: int
    max_occupancy: int
    created_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> dict[str, Any]:
        return {
            'roomtype_id': self.roomtype_id,
            'property_id': self.property_id,
            'property_code': self.property_code,
            'room_type_code': self.room_type_code,
            'room_type_name': self.room_type_name,
            'base_physical_count': self.base_physical_count,
            'max_occupancy': self.max_occupancy,
            'created_by': self.created_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class RoomTypeUpdatedEvent:
    """Event published when a room type is updated"""
    roomtype_id: str
    property_id: str
    property_code: str
    room_type_code: str
    changes: dict[str, Any]
    updated_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> dict[str, Any]:
        return {
            'roomtype_id': self.roomtype_id,
            'property_id': self.property_id,
            'property_code': self.property_code,
            'room_type_code': self.room_type_code,
            'changes': self.changes,
            'updated_by': self.updated_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class RoomTypeDeletedEvent:
    """Event published when a room type is deleted"""
    roomtype_id: str
    property_id: str
    property_code: str
    room_type_code: str
    deleted_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> dict[str, Any]:
        return {
            'roomtype_id': self.roomtype_id,
            'property_id': self.property_id,
            'property_code': self.property_code,
            'room_type_code': self.room_type_code,
            'deleted_by': self.deleted_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }
