from rest_framework import permissions
from typing import Any


class IsPropertyAdminOrReadOnly(permissions.BasePermission):
    def has_permission(self, request: Any, view: Any) -> bool:
        # Check if user is authenticated
        if not request.user or not request.user.is_authenticated:
            return False
        
        # SUPER_ADMIN has all permissions
        if request.user.role == 'SUPER_ADMIN':
            return True
        
        # STAFF can only read
        if request.user.role == 'STAFF':
            return request.method in permissions.SAFE_METHODS
        
        # PROPERTY_ADMIN can create, update, delete
        if request.user.role == 'PROPERTY_ADMIN':
            return True
        
        # No access for others
        return False


class IsSuperAdminOrPropertyAdmin(permissions.BasePermission):
    def has_permission(self, request: Any, view: Any) -> bool:
        if not request.user or not request.user.is_authenticated:
            return False
        
        return request.user.role in ['SUPER_ADMIN', 'PROPERTY_ADMIN']


class IsSuperAdmin(permissions.BasePermission):
    def has_permission(self, request: Any, view: Any) -> bool:
        if not request.user or not request.user.is_authenticated:
            return False
        
        return request.user.role == 'SUPER_ADMIN'
