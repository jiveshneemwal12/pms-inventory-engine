from rest_framework import serializers
from .models import Property, RoomType
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Dict


class RoomTypeSerializer(serializers.ModelSerializer):
    total_units = serializers.IntegerField(source='base_physical_count', read_only=True)
    
    class Meta:
        model = RoomType
        fields = [
            'id',
            'property',
            'room_type_code',
            'room_type_name',
            'base_physical_count',
            'total_units',
            'max_occupancy',
            'description',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'total_units']
    
    def validate_room_type_code(self, value: str) -> str:
        return value.upper()
    
    def validate_base_physical_count(self, value: int) -> int:
        if value < 1:
            raise serializers.ValidationError("Base physical count must be at least 1.")
        return value
    
    def validate_max_occupancy(self, value: int) -> int:
        if value < 1:
            raise serializers.ValidationError("Max occupancy must be at least 1.")
        return value
    
    def validate(self, attrs: dict[str, Any]) -> dict[str, Any]:
        property_obj = attrs.get('property')
        room_type_code = attrs.get('room_type_code', '').upper()
        
        # Skip validation if no property or room_type_code
        if not property_obj or not room_type_code:
            return attrs
        
        # For update, check if room_type_code changed
        if self.instance:
            if room_type_code == self.instance.room_type_code.upper():
                return attrs
        
        # Check uniqueness
        if RoomType.objects.filter(property=property_obj, room_type_code=room_type_code).exists():
            raise serializers.ValidationError({
                'room_type_code': f"Room type code '{room_type_code}' already exists for this property."
            })
        
        return attrs


class RoomTypeListSerializer(serializers.ModelSerializer):
    total_units = serializers.IntegerField(source='base_physical_count', read_only=True)
    
    class Meta:
        model = RoomType
        fields = [
            'id',
            'room_type_code',
            'room_type_name',
            'base_physical_count',
            'total_units',
            'max_occupancy',
        ]


class PropertySerializer(serializers.ModelSerializer):
    room_types = RoomTypeListSerializer(many=True, read_only=True)
    room_types_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Property
        fields = [
            'id',
            'property_code',
            'property_name',
            'timezone',
            'status',
            'address',
            'city',
            'country',
            'room_types',
            'room_types_count',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'room_types', 'room_types_count']
    
    def get_room_types_count(self, obj: Property) -> int:
        return obj.room_types.count()
    
    def validate_property_code(self, value: str) -> str:
        return value.upper()
    
    def validate_status(self, value: str) -> str:
        allowed_statuses = ['ACTIVE', 'INACTIVE', 'MAINTENANCE']
        if value not in allowed_statuses:
            raise serializers.ValidationError(
                f"Status must be one of: {', '.join(allowed_statuses)}"
            )
        return value
    
    def validate(self, attrs: dict[str, Any]) -> dict[str, Any]:
        property_code = attrs.get('property_code', '').upper()
        
        # Skip validation if no property_code
        if not property_code:
            return attrs
        
        # For update, check if property_code changed
        if self.instance:
            if property_code == self.instance.property_code.upper():
                return attrs
        
        # Check uniqueness
        if Property.objects.filter(property_code=property_code).exists():
            raise serializers.ValidationError({
                'property_code': f"Property code '{property_code}' already exists."
            })
        
        return attrs


class PropertyListSerializer(serializers.ModelSerializer):
    room_types_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Property
        fields = [
            'id',
            'property_code',
            'property_name',
            'city',
            'country',
            'status',
            'room_types_count',
        ]
    
    def get_room_types_count(self, obj: Property) -> int:
        return obj.room_types.count()


class PropertyDetailSerializer(serializers.ModelSerializer):
    room_types = RoomTypeSerializer(many=True, read_only=True)
    
    class Meta:
        model = Property
        fields = [
            'id',
            'property_code',
            'property_name',
            'timezone',
            'status',
            'address',
            'city',
            'country',
            'room_types',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'room_types']
