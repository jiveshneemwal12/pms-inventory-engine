from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.request import Request
from django.db.models import QuerySet
from typing import Any, cast, Optional
from datetime import datetime
import uuid
import logging

from .models import Property, RoomType
from .serializers import (
    PropertySerializer,
    PropertyListSerializer,
    PropertyDetailSerializer,
    RoomTypeSerializer,
    RoomTypeListSerializer,
)
from .permissions import IsPropertyAdminOrReadOnly
from .cache import (
    cache_property,
    cache_roomtype,
    invalidate_property_cache,
    invalidate_roomtype_cache,
    get_cached_property_by_id,
    get_cached_roomtype_by_id,
)
from .events import (
    PropertyCreatedEvent,
    PropertyUpdatedEvent,
    PropertyStatusChangedEvent,
    PropertyDeletedEvent,
    RoomTypeCreatedEvent,
    RoomTypeUpdatedEvent,
    RoomTypeDeletedEvent,
)
from apps.events.producer import get_producer
from apps.common.response import create_response

logger = logging.getLogger(__name__)


class PropertyViewSet(viewsets.ModelViewSet):
    queryset = Property.objects.all().prefetch_related('room_types')
    permission_classes = [IsPropertyAdminOrReadOnly]
    lookup_field = 'id'
    
    def get_serializer_class(self):
        if self.action == 'list':
            return PropertyListSerializer
        elif self.action == 'retrieve':
            return PropertyDetailSerializer
        return PropertySerializer
    
    def get_queryset(self) -> QuerySet:
        queryset = super().get_queryset()
        
        # Filter by status
        status_param = self.request.query_params.get('status')
        if status_param:
            queryset = queryset.filter(status=status_param.upper())
        
        # Filter by city
        city = self.request.query_params.get('city')
        if city:
            queryset = queryset.filter(city__icontains=city)
        
        # Filter by country
        country = self.request.query_params.get('country')
        if country:
            queryset = queryset.filter(country__icontains=country)
        
        # Search by property code or name
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                property_code__icontains=search
            ) | queryset.filter(
                property_name__icontains=search
            )
        
        return queryset.order_by('-created_at')
    
    def list(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = self.get_serializer(queryset, many=True)
        return create_response(
                status_type='success',
                message='Properties retrieved successfully',
                data={'properties': serializer.data}
            )
    
    def retrieve(self, request: Request, *args: Any, **kwargs: Any) -> Response:
            property_id = kwargs.get('id')
            
            # Try to get from cache
            cached_data = get_cached_property_by_id(str(property_id))
            if cached_data and request.method == 'GET':
                logger.debug(f"Returning cached data for property {property_id}")
                # Still need to fetch room types from DB
                instance = self.get_object()
                serializer = self.get_serializer(instance)
                return create_response(
                        status_type='success',
                        message='Property retrieved successfully',
                        data={'property': serializer.data}
                    )
            
            instance = self.get_object()
            serializer = self.get_serializer(instance)
            
            # Cache the property
            cache_property(instance)
            
            return create_response(
                    status_type='success',
                    message='Property retrieved successfully',
                    data={'property': serializer.data}
                )
    
    def create(self, request: Request, *args: Any, **kwargs: Any) -> Response:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            property_obj = cast(Property, serializer.save())
            
            # Cache the new property
            cache_property(property_obj)
            
            # Publish Kafka event
            correlation_id = str(uuid.uuid4())
            try:
                event = PropertyCreatedEvent(
                    property_id=str(property_obj.id),
                    property_code=property_obj.property_code,
                    property_name=property_obj.property_name,
                    timezone=property_obj.timezone,
                    status=property_obj.status,
                    city=property_obj.city,
                    country=property_obj.country,
                    created_by=request.user.email,
                    timestamp=datetime.utcnow().isoformat(),
                    correlation_id=correlation_id,
                )
                get_producer().publish('PROPERTY_CREATED', event)
                logger.info(f"Published PROPERTY_CREATED event for {property_obj.property_code}")
            except Exception as e:
                logger.error(f"Failed to publish PROPERTY_CREATED event: {str(e)}")
            
            return create_response(
                    status_type='success',
                    message='Property created successfully',
                    data={'property': serializer.data},
                http_status=status.HTTP_201_CREATED
            )
    
    def update(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        old_status = instance.status
        old_data = PropertySerializer(instance).data
        
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        property_obj = cast(Property, serializer.save())
        
        # Invalidate and recache
        invalidate_property_cache(property_obj)
        cache_property(property_obj)
        
        # Calculate changes
        new_data = serializer.data
        changes = {
            key: {'old': old_data.get(key), 'new': new_data.get(key)}
            for key in new_data
            if old_data.get(key) != new_data.get(key) and key not in ['updated_at', 'room_types', 'room_types_count']
        }
        
        # Publish Kafka event
        correlation_id = str(uuid.uuid4())
        try:
            event = PropertyUpdatedEvent(
                property_id=str(property_obj.id),
                property_code=property_obj.property_code,
                changes=changes,
                updated_by=request.user.email,
                timestamp=datetime.utcnow().isoformat(),
                correlation_id=correlation_id,
            )
            get_producer().publish('PROPERTY_UPDATED', event)
            logger.info(f"Published PROPERTY_UPDATED event for {property_obj.property_code}")
        except Exception as e:
            logger.error(f"Failed to publish PROPERTY_UPDATED event: {str(e)}")
        
        # Publish status change event if status changed
        if old_status != property_obj.status:
            try:
                status_event = PropertyStatusChangedEvent(
                    property_id=str(property_obj.id),
                    property_code=property_obj.property_code,
                    old_status=old_status,
                    new_status=property_obj.status,
                    changed_by=request.user.email,
                    timestamp=datetime.utcnow().isoformat(),
                    correlation_id=correlation_id,
                )
                get_producer().publish('PROPERTY_STATUS_CHANGED', status_event)
                logger.info(f"Published PROPERTY_STATUS_CHANGED event for {property_obj.property_code}")
            except Exception as e:
                logger.error(f"Failed to publish PROPERTY_STATUS_CHANGED event: {str(e)}")
        
        return create_response(
                status_type='success',
                message='Property updated successfully',
                data={'property': serializer.data}
            )
    
    def partial_update(self, request: Request, *args: Any, **kwargs: Any) -> Response:
            kwargs['partial'] = True
            return self.update(request, *args, **kwargs)
    
    def destroy(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        instance = self.get_object()
        property_code = instance.property_code
        property_id = str(instance.id)
        
        # Check if property has room types
        if instance.room_types.exists():
            return create_response(
                    status_type='error',
                    message='Cannot delete property with existing room types',
                    errors={'detail': 'Please delete all room types first'},
                    http_status=status.HTTP_400_BAD_REQUEST
            )
        
        # Delete from DB
        instance.delete()
        
        # Invalidate cache
        invalidate_property_cache(instance)
        
        # Publish Kafka event
        correlation_id = str(uuid.uuid4())
        try:
            event = PropertyDeletedEvent(
                property_id=property_id,
                property_code=property_code,
                deleted_by=request.user.email,
                timestamp=datetime.utcnow().isoformat(),
                correlation_id=correlation_id,
            )
            get_producer().publish('PROPERTY_DELETED', event)
            logger.info(f"Published PROPERTY_DELETED event for {property_code}")
        except Exception as e:
            logger.error(f"Failed to publish PROPERTY_DELETED event: {str(e)}")
        
        return create_response(
                status_type='success',
                message='Property deleted successfully',
                data={'property_code': property_code},
                http_status=status.HTTP_200_OK
        )
    
    @action(detail=True, methods=['post'], permission_classes=[IsPropertyAdminOrReadOnly])
    def activate(self, request: Request, id: Optional[str] = None) -> Response:
        instance = self.get_object()
        old_status = instance.status
        instance.status = 'ACTIVE'
        instance.save()
        
        # Invalidate and recache
        invalidate_property_cache(instance)
        cache_property(instance)
        
        # Publish status change event
        correlation_id = str(uuid.uuid4())
        try:
            event = PropertyStatusChangedEvent(
                property_id=str(instance.id),
                property_code=instance.property_code,
                old_status=old_status,
                new_status='ACTIVE',
                changed_by=request.user.email,
                timestamp=datetime.utcnow().isoformat(),
                correlation_id=correlation_id,
            )
            get_producer().publish('PROPERTY_STATUS_CHANGED', event)
            logger.info(f"Published PROPERTY_STATUS_CHANGED event for {instance.property_code}")
        except Exception as e:
            logger.error(f"Failed to publish PROPERTY_STATUS_CHANGED event: {str(e)}")
        
        serializer = self.get_serializer(instance)
        return create_response(
                status_type='success',
                message='Property activated successfully',
                data={'property': serializer.data}
            )
    
    @action(detail=True, methods=['post'], permission_classes=[IsPropertyAdminOrReadOnly])
    def deactivate(self, request: Request, id: Optional[str] = None) -> Response:
        """Deactivate a property"""
        instance = self.get_object()
        old_status = instance.status
        instance.status = 'INACTIVE'
        instance.save()
        
        # Invalidate and recache
        invalidate_property_cache(instance)
        cache_property(instance)
        
        # Publish status change event
        correlation_id = str(uuid.uuid4())
        try:
            event = PropertyStatusChangedEvent(
                property_id=str(instance.id),
                property_code=instance.property_code,
                old_status=old_status,
                new_status='INACTIVE',
                changed_by=request.user.email,
                timestamp=datetime.utcnow().isoformat(),
                correlation_id=correlation_id,
            )
            get_producer().publish('PROPERTY_STATUS_CHANGED', event)
            logger.info(f"Published PROPERTY_STATUS_CHANGED event for {instance.property_code}")
        except Exception as e:
            logger.error(f"Failed to publish PROPERTY_STATUS_CHANGED event: {str(e)}")
        
        serializer = self.get_serializer(instance)
        return create_response(
                status_type='success',
                message='Property deactivated successfully',
                data={'property': serializer.data}
            )


class RoomTypeViewSet(viewsets.ModelViewSet):
    queryset = RoomType.objects.all().select_related('property')
    permission_classes = [IsPropertyAdminOrReadOnly]
    lookup_field = 'id'
    
    def get_serializer_class(self):
        if self.action == 'list':
            return RoomTypeListSerializer
        return RoomTypeSerializer
    
    def get_queryset(self) -> QuerySet:
        queryset = super().get_queryset()
        
        # Filter by property
        property_id = self.request.query_params.get('property_id')
        if property_id:
            queryset = queryset.filter(property_id=property_id)
        
        property_code = self.request.query_params.get('property_code')
        if property_code:
            queryset = queryset.filter(property__property_code=property_code.upper())
        
        # Search by room type code or name
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                room_type_code__icontains=search
            ) | queryset.filter(
                room_type_name__icontains=search
            )
        
        return queryset.order_by('property', 'room_type_code')
    
    def list(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = self.get_serializer(queryset, many=True)
        return create_response(
                status_type='success',
                message='Room types retrieved successfully',
                data={'room_types': serializer.data}
            )
    
    def retrieve(self, request: Request, *args: Any, **kwargs: Any) -> Response:
            roomtype_id = kwargs.get('id')
            
            # Try to get from cache
            cached_data = get_cached_roomtype_by_id(str(roomtype_id))
            if cached_data and request.method == 'GET':
                logger.debug(f"Returning cached data for room type {roomtype_id}")
                instance = self.get_object()
                serializer = self.get_serializer(instance)
                return create_response(
                        status_type='success',
                        message='Room type retrieved successfully',
                        data={'room_type': serializer.data}
                    )
            
            instance = self.get_object()
            serializer = self.get_serializer(instance)
            
            # Cache the room type
            cache_roomtype(instance)
            
            return create_response(
                    status_type='success',
                    message='Room type retrieved successfully',
                    data={'room_type': serializer.data}
                )
        
    def create(self, request: Request, *args: Any, **kwargs: Any) -> Response:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            roomtype_obj = cast(RoomType, serializer.save())
            
            # Cache the new room type
            cache_roomtype(roomtype_obj)
            
            # Invalidate property cache (room_types count changed)
            invalidate_property_cache(roomtype_obj.property)
            
            # Publish Kafka event
            correlation_id = str(uuid.uuid4())
            try:
                event = RoomTypeCreatedEvent(
                    roomtype_id=str(roomtype_obj.id),
                    property_id=str(roomtype_obj.property_id),
                    property_code=roomtype_obj.property.property_code,
                    room_type_code=roomtype_obj.room_type_code,
                    room_type_name=roomtype_obj.room_type_name,
                    base_physical_count=roomtype_obj.base_physical_count,
                    max_occupancy=roomtype_obj.max_occupancy,
                    created_by=request.user.email,
                    timestamp=datetime.utcnow().isoformat(),
                    correlation_id=correlation_id,
                )
                get_producer().publish('ROOMTYPE_CREATED', event)
                logger.info(f"Published ROOMTYPE_CREATED event for {roomtype_obj.room_type_code}")
            except Exception as e:
                logger.error(f"Failed to publish ROOMTYPE_CREATED event: {str(e)}")
            
            return create_response(
                    status_type='success',
                    message='Room type created successfully',
                    data={'room_type': serializer.data},
                    http_status=status.HTTP_201_CREATED
            )
    
    def update(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        old_data = RoomTypeSerializer(instance).data
        
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        roomtype_obj = cast(RoomType, serializer.save())
        
        # Invalidate and recache
        invalidate_roomtype_cache(roomtype_obj)
        cache_roomtype(roomtype_obj)
        
        # Invalidate property cache
        invalidate_property_cache(roomtype_obj.property)
        
        # Calculate changes
        new_data = serializer.data
        changes = {
            key: {'old': old_data.get(key), 'new': new_data.get(key)}
            for key in new_data
            if old_data.get(key) != new_data.get(key) and key not in ['updated_at']
        }
        
        # Publish Kafka event
        correlation_id = str(uuid.uuid4())
        try:
            event = RoomTypeUpdatedEvent(
                roomtype_id=str(roomtype_obj.id),
                property_id=str(roomtype_obj.property_id),
                property_code=roomtype_obj.property.property_code,
                room_type_code=roomtype_obj.room_type_code,
                changes=changes,
                updated_by=request.user.email,
                timestamp=datetime.utcnow().isoformat(),
                correlation_id=correlation_id,
            )
            get_producer().publish('ROOMTYPE_UPDATED', event)
            logger.info(f"Published ROOMTYPE_UPDATED event for {roomtype_obj.room_type_code}")
        except Exception as e:
            logger.error(f"Failed to publish ROOMTYPE_UPDATED event: {str(e)}")
        
        return create_response(
                status_type='success',
                message='Room type updated successfully',
                data={'room_type': serializer.data}
            )
    
    def partial_update(self, request: Request, *args: Any, **kwargs: Any) -> Response:
            kwargs['partial'] = True
            return self.update(request, *args, **kwargs)
    
    def destroy(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        instance = self.get_object()
        room_type_code = instance.room_type_code
        roomtype_id = str(instance.id)
        property_id = str(instance.property_id)
        property_code = instance.property.property_code
        
        # Delete from DB
        instance.delete()
        
        # Invalidate cache
        invalidate_roomtype_cache(instance)
        invalidate_property_cache(instance.property)
        
        # Publish Kafka event
        correlation_id = str(uuid.uuid4())
        try:
            event = RoomTypeDeletedEvent(
                roomtype_id=roomtype_id,
                property_id=property_id,
                property_code=property_code,
                room_type_code=room_type_code,
                deleted_by=request.user.email,
                timestamp=datetime.utcnow().isoformat(),
                correlation_id=correlation_id,
            )
            get_producer().publish('ROOMTYPE_DELETED', event)
            logger.info(f"Published ROOMTYPE_DELETED event for {room_type_code}")
        except Exception as e:
            logger.error(f"Failed to publish ROOMTYPE_DELETED event: {str(e)}")
        
        return create_response(
                status_type='success',
                message='Room type deleted successfully',
                data={'room_type_code': room_type_code},
                http_status=status.HTTP_200_OK
        )
