"""
Django admin configuration for properties app.
"""
from django.contrib import admin
from .models import Property, RoomType


class RoomTypeInline(admin.TabularInline):
    """Inline admin for RoomType within Property admin"""
    model = RoomType
    extra = 0
    fields = ['room_type_code', 'room_type_name', 'base_physical_count', 'max_occupancy', 'description']
    readonly_fields = []


@admin.register(Property)
class PropertyAdmin(admin.ModelAdmin):
    """Admin interface for Property model"""
    list_display = [
        'property_code',
        'property_name',
        'city',
        'country',
        'status',
        'timezone',
        'created_at',
    ]
    list_filter = ['status', 'country', 'city', 'timezone']
    search_fields = ['property_code', 'property_name', 'city', 'country', 'address']
    ordering = ['-created_at']
    readonly_fields = ['id', 'created_at', 'updated_at']
    inlines = [RoomTypeInline]
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('id', 'property_code', 'property_name', 'status')
        }),
        ('Location', {
            'fields': ('address', 'city', 'country', 'timezone')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )


@admin.register(RoomType)
class RoomTypeAdmin(admin.ModelAdmin):
    """Admin interface for RoomType model"""
    list_display = [
        'room_type_code',
        'room_type_name',
        'property',
        'base_physical_count',
        'max_occupancy',
        'created_at',
    ]
    list_filter = ['property', 'max_occupancy']
    search_fields = [
        'room_type_code',
        'room_type_name',
        'property__property_code',
        'property__property_name',
    ]
    ordering = ['property', 'room_type_code']
    readonly_fields = ['id', 'created_at', 'updated_at']
    autocomplete_fields = ['property']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('id', 'property', 'room_type_code', 'room_type_name')
        }),
        ('Capacity', {
            'fields': ('base_physical_count', 'max_occupancy', 'description')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )
