"""
Cache utilities for properties management.
"""
from django.core.cache import cache
from typing import Optional
import logging

logger = logging.getLogger(__name__)

# Cache TTL settings
PROPERTY_CACHE_TTL = 3600  # 1 hour
PROPERTY_CODE_CACHE_TTL = 3600  # 1 hour
ROOMTYPE_CACHE_TTL = 3600  # 1 hour


def get_property_cache_key(property_id: str) -> str:
    """Generate cache key for property by ID"""
    return f"property:{property_id}"


def get_property_code_cache_key(property_code: str) -> str:
    """Generate cache key for property by code"""
    return f"property:code:{property_code.upper()}"


def get_roomtype_cache_key(roomtype_id: str) -> str:
    """Generate cache key for room type by ID"""
    return f"roomtype:{roomtype_id}"


def get_property_roomtypes_cache_key(property_id: str) -> str:
    """Generate cache key for property's room types list"""
    return f"property:{property_id}:roomtypes"


def cache_property(property_obj) -> None:
    """
    Cache property data by both ID and code.
    
    Args:
        property_obj: Property model instance
    """
    try:
        property_data = {
            'id': str(property_obj.id),
            'property_code': property_obj.property_code,
            'property_name': property_obj.property_name,
            'timezone': property_obj.timezone,
            'status': property_obj.status,
            'address': property_obj.address,
            'city': property_obj.city,
            'country': property_obj.country,
        }
        
        # Cache by property ID
        cache.set(get_property_cache_key(str(property_obj.id)), property_data, PROPERTY_CACHE_TTL)
        
        # Cache by property code
        cache.set(get_property_code_cache_key(property_obj.property_code), property_data, PROPERTY_CODE_CACHE_TTL)
        
        logger.debug(f"Cached property data for {property_obj.property_code}")
    except Exception as e:
        logger.error(f"Failed to cache property {property_obj.property_code}: {str(e)}")


def cache_roomtype(roomtype_obj) -> None:
    """
    Cache room type data.
    
    Args:
        roomtype_obj: RoomType model instance
    """
    try:
        roomtype_data = {
            'id': str(roomtype_obj.id),
            'property_id': str(roomtype_obj.property_id),
            'room_type_code': roomtype_obj.room_type_code,
            'room_type_name': roomtype_obj.room_type_name,
            'base_physical_count': roomtype_obj.base_physical_count,
            'max_occupancy': roomtype_obj.max_occupancy,
            'description': roomtype_obj.description,
        }
        
        # Cache by room type ID
        cache.set(get_roomtype_cache_key(str(roomtype_obj.id)), roomtype_data, ROOMTYPE_CACHE_TTL)
        
        logger.debug(f"Cached room type data for {roomtype_obj.room_type_code}")
    except Exception as e:
        logger.error(f"Failed to cache room type {roomtype_obj.room_type_code}: {str(e)}")


def get_cached_property_by_id(property_id: str) -> Optional[dict]:
    """Get property data from cache by ID"""
    try:
        cached_data = cache.get(get_property_cache_key(property_id))
        if cached_data:
            logger.debug(f"Cache hit for property ID: {property_id}")
            return cached_data
        logger.debug(f"Cache miss for property ID: {property_id}")
        return None
    except Exception as e:
        logger.error(f"Failed to get cached property by ID {property_id}: {str(e)}")
        return None


def get_cached_property_by_code(property_code: str) -> Optional[dict]:
    """Get property data from cache by code"""
    try:
        cached_data = cache.get(get_property_code_cache_key(property_code))
        if cached_data:
            logger.debug(f"Cache hit for property code: {property_code}")
            return cached_data
        logger.debug(f"Cache miss for property code: {property_code}")
        return None
    except Exception as e:
        logger.error(f"Failed to get cached property by code {property_code}: {str(e)}")
        return None


def get_cached_roomtype_by_id(roomtype_id: str) -> Optional[dict]:
    """Get room type data from cache by ID"""
    try:
        cached_data = cache.get(get_roomtype_cache_key(roomtype_id))
        if cached_data:
            logger.debug(f"Cache hit for room type ID: {roomtype_id}")
            return cached_data
        logger.debug(f"Cache miss for room type ID: {roomtype_id}")
        return None
    except Exception as e:
        logger.error(f"Failed to get cached room type by ID {roomtype_id}: {str(e)}")
        return None


def invalidate_property_cache(property_obj) -> None:
    """
    Invalidate all cache entries for a property.
    
    Args:
        property_obj: Property model instance or dict with id and property_code
    """
    try:
        property_id = str(property_obj.id) if hasattr(property_obj, 'id') else str(property_obj.get('id'))
        property_code = property_obj.property_code if hasattr(property_obj, 'property_code') else property_obj.get('property_code')
        
        cache.delete(get_property_cache_key(property_id))
        cache.delete(get_property_code_cache_key(property_code))
        cache.delete(get_property_roomtypes_cache_key(property_id))
        
        logger.info(f"Invalidated cache for property: {property_code}")
    except Exception as e:
        logger.error(f"Failed to invalidate property cache: {str(e)}")


def invalidate_roomtype_cache(roomtype_obj) -> None:
    """
    Invalidate cache entries for a room type.
    
    Args:
        roomtype_obj: RoomType model instance
    """
    try:
        roomtype_id = str(roomtype_obj.id) if hasattr(roomtype_obj, 'id') else str(roomtype_obj.get('id'))
        property_id = str(roomtype_obj.property_id) if hasattr(roomtype_obj, 'property_id') else str(roomtype_obj.get('property_id'))
        
        cache.delete(get_roomtype_cache_key(roomtype_id))
        cache.delete(get_property_roomtypes_cache_key(property_id))
        
        logger.info(f"Invalidated cache for room type: {roomtype_id}")
    except Exception as e:
        logger.error(f"Failed to invalidate room type cache: {str(e)}")
