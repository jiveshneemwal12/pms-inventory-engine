"""
Properties app - Property & room definitions.
"""
