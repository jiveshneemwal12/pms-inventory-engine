from django.db import models
from apps.common.models import UUIDModel, TimeStampedModel
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from django.db.models.manager import RelatedManager

class Property(UUIDModel, TimeStampedModel):
    property_code = models.CharField(
        max_length=20,
        unique=True,
        help_text='Unique property code identifier'
    )
    property_name = models.CharField(max_length=255, db_column='property_name')
    timezone = models.CharField(max_length=50)
    status = models.CharField(
        max_length=20,
        default='ACTIVE',
        choices=[
            ('ACTIVE', 'Active'),
            ('INACTIVE', 'Inactive'),
            ('MAINTENANCE', 'Maintenance'),
        ]
    )

    address = models.TextField(blank=True)
    city = models.CharField(max_length=100, blank=True)
    country = models.CharField(max_length=100, blank=True)
    
    if TYPE_CHECKING:
        room_types: 'RelatedManager[RoomType]'
    
    class Meta:
        db_table = 'properties'
        verbose_name = 'Property'
        verbose_name_plural = 'Properties'
    
    def __str__(self):
        return f"{self.property_code} - {self.property_name}"


class RoomType(UUIDModel, TimeStampedModel):
    property = models.ForeignKey(
        Property, 
        on_delete=models.CASCADE, 
        related_name='room_types',
        db_column='property_id'
    )
    room_type_code = models.CharField(
        max_length=20,
        help_text='Unique code within property'
    )
    room_type_name = models.CharField(max_length=100, db_column='room_type_name')
    base_physical_count = models.PositiveIntegerField(
        help_text='Base number of physical units for this room type'
    )
    max_occupancy = models.PositiveIntegerField()
    description = models.TextField(blank=True)
    
    class Meta:
        db_table = 'room_types'
        verbose_name = 'Room Type'
        verbose_name_plural = 'Room Types'
        unique_together = ('property', 'room_type_code')
    
    def __str__(self):
        return f"{self.property.property_code} - {self.room_type_code}"
    
    def total_units(self):
        return self.base_physical_count
