"""
Utility to broadcast realtime updates via WebSockets.
"""
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync


def broadcast_inventory_update(room_type_id, date, available_units):
    """
    Broadcast inventory update to all connected clients.
    """
    channel_layer = get_channel_layer()
    
    async_to_sync(channel_layer.group_send)(
        'inventory_dashboard',
        {
            'type': 'inventory_update',
            'data': {
                'room_type_id': str(room_type_id),
                'date': str(date),
                'available_units': available_units
            }
        }
    )


def broadcast_reservation_event(event_type, reservation_data):
    """
    Broadcast reservation event to all connected clients.
    """
    channel_layer = get_channel_layer()
    
    async_to_sync(channel_layer.group_send)(
        'reservation_feed',
        {
            'type': 'reservation_event',
            'data': {
                'event_type': event_type,
                'reservation': reservation_data
            }
        }
    )
