"""
WebSocket consumers for realtime updates.
Read-only - NO writes, NO booking logic.
"""
import json
from channels.generic.websocket import AsyncWebsocketConsumer


class InventoryDashboardConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for live inventory dashboard.
    Broadcasts inventory updates to connected clients.
    """
    
    async def connect(self):
        self.room_group_name = 'inventory_dashboard'
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        
        await self.accept()
    
    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )
    
    async def receive(self, text_data):
        """
        Receive message from WebSocket.
        This is read-only - we don't process any write commands.
        """
        pass
    
    async def inventory_update(self, event):
        """
        Receive inventory update from room group.
        """
        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'inventory_update',
            'data': event['data']
        }))


class ReservationFeedConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for live reservation feed.
    Broadcasts reservation events to connected clients.
    """
    
    async def connect(self):
        self.room_group_name = 'reservation_feed'
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        
        await self.accept()
    
    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )
    
    async def receive(self, text_data):
        """
        Receive message from WebSocket.
        This is read-only - we don't process any write commands.
        """
        pass
    
    async def reservation_event(self, event):
        """
        Receive reservation event from room group.
        """
        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'reservation_event',
            'data': event['data']
        }))
