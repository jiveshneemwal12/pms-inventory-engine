"""
Realtime app - WebSocket support.
Read-only, no DB writes, no booking logic.
"""
