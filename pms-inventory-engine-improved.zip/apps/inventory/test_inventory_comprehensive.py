"""
Comprehensive test suite for the Inventory Management Engine.
Tests cover core functionality, concurrency, edge cases, and performance.
"""

from django.test import TestCase, TransactionTestCase
from django.utils import timezone
from datetime import date, timedelta
import uuid

from apps.properties.models import Property, RoomType
from apps.inventory.models import InventoryCalendar, InventoryEvent, InventoryHold
from apps.inventory.services import InventoryService
from apps.common.exceptions import InsufficientInventoryException, InventoryLockException


class InventoryPreloadTests(TestCase):
    """Test inventory preloading functionality."""
    
    def setUp(self):
        self.property = Property.objects.create(
            property_code='TEST_PROP',
            property_name='Test Property',
            timezone='UTC'
        )
        self.room_type = RoomType.objects.create(
            property=self.property,
            room_type_code='DELUXE',
            room_type_name='Deluxe Room',
            base_physical_count=10,
            max_occupancy=2
        )
        self.today = date.today()
    
    def test_preload_creates_correct_count(self):
        """Test that preload creates the correct number of inventory records."""
        days = 30
        InventoryService.preload_inventory(self.room_type, self.today, days=days)
        
        count = InventoryCalendar.objects.filter(
            room_type=self.room_type,
            stay_date__gte=self.today
        ).count()
        
        self.assertEqual(count, days)
    
    def test_preload_sets_correct_physical_count(self):
        """Test that preload sets the correct physical count."""
        InventoryService.preload_inventory(self.room_type, self.today, days=1)
        
        inv = InventoryCalendar.objects.get(
            room_type=self.room_type,
            stay_date=self.today
        )
        
        self.assertEqual(inv.physical_count, self.room_type.base_physical_count)
        self.assertEqual(inv.sold_count, 0)
        self.assertEqual(inv.held_count, 0)
    
    def test_preload_idempotency(self):
        """Test that preload is idempotent."""
        correlation_id = uuid.uuid4()
        
        InventoryService.preload_inventory(
            self.room_type, self.today, days=5, correlation_id=correlation_id
        )
        count_first = InventoryCalendar.objects.filter(room_type=self.room_type).count()
        
        # Preload again with same correlation_id
        InventoryService.preload_inventory(
            self.room_type, self.today, days=5, correlation_id=correlation_id
        )
        count_second = InventoryCalendar.objects.filter(room_type=self.room_type).count()
        
        self.assertEqual(count_first, count_second)


class InventoryReservationTests(TransactionTestCase):
    """Test inventory reservation (blocking) functionality."""
    
    def setUp(self):
        self.property = Property.objects.create(
            property_code='TEST_PROP',
            property_name='Test Property',
            timezone='UTC'
        )
        self.room_type = RoomType.objects.create(
            property=self.property,
            room_type_code='DELUXE',
            room_type_name='Deluxe Room',
            base_physical_count=10,
            max_occupancy=2
        )
        self.today = date.today()
        InventoryService.preload_inventory(self.room_type, self.today, days=10)
    
    def test_reserve_updates_sold_count(self):
        """Test that reserve correctly updates sold_count."""
        start_date = self.today
        end_date = self.today + timedelta(days=3)
        quantity = 2
        
        InventoryService.reserve(self.room_type, start_date, end_date, quantity)
        
        for i in range(3):
            inv = InventoryCalendar.objects.get(
                room_type=self.room_type,
                stay_date=start_date + timedelta(days=i)
            )
            self.assertEqual(inv.sold_count, quantity)
    
    def test_reserve_insufficient_inventory(self):
        """Test that reserve raises exception when inventory is insufficient."""
        start_date = self.today
        end_date = self.today + timedelta(days=1)
        quantity = 15  # More than physical count
        
        with self.assertRaises(InsufficientInventoryException):
            InventoryService.reserve(self.room_type, start_date, end_date, quantity)
    
    def test_reserve_idempotency(self):
        """Test that reserve is idempotent with same correlation_id."""
        start_date = self.today
        end_date = self.today + timedelta(days=2)
        quantity = 2
        correlation_id = uuid.uuid4()
        
        InventoryService.reserve(
            self.room_type, start_date, end_date, quantity, correlation_id=correlation_id
        )
        
        events_first = InventoryEvent.objects.filter(
            room_type=self.room_type,
            event_type='RESERVED',
            correlation_id=correlation_id
        ).count()
        
        InventoryService.reserve(
            self.room_type, start_date, end_date, quantity, correlation_id=correlation_id
        )
        
        events_second = InventoryEvent.objects.filter(
            room_type=self.room_type,
            event_type='RESERVED',
            correlation_id=correlation_id
        ).count()
        
        self.assertEqual(events_first, events_second)


class InventoryReleaseTests(TransactionTestCase):
    """Test inventory release functionality."""
    
    def setUp(self):
        self.property = Property.objects.create(
            property_code='TEST_PROP',
            property_name='Test Property',
            timezone='UTC'
        )
        self.room_type = RoomType.objects.create(
            property=self.property,
            room_type_code='DELUXE',
            room_type_name='Deluxe Room',
            base_physical_count=10,
            max_occupancy=2
        )
        self.today = date.today()
        InventoryService.preload_inventory(self.room_type, self.today, days=10)
    
    def test_release_decreases_sold_count(self):
        """Test that release correctly decreases sold_count."""
        start_date = self.today
        end_date = self.today + timedelta(days=3)
        quantity = 2
        
        # Reserve first
        InventoryService.reserve(self.room_type, start_date, end_date, quantity)
        
        # Release
        InventoryService.release(self.room_type, start_date, end_date, quantity)
        
        for i in range(3):
            inv = InventoryCalendar.objects.get(
                room_type=self.room_type,
                stay_date=start_date + timedelta(days=i)
            )
            self.assertEqual(inv.sold_count, 0)
    
    def test_release_partial(self):
        """Test partial release of reserved inventory."""
        start_date = self.today
        end_date = self.today + timedelta(days=1)
        
        # Reserve 5 units
        InventoryService.reserve(self.room_type, start_date, end_date, 5)
        
        # Release 2 units
        InventoryService.release(self.room_type, start_date, end_date, 2)
        
        inv = InventoryCalendar.objects.get(
            room_type=self.room_type,
            stay_date=start_date
        )
        self.assertEqual(inv.sold_count, 3)


class InventoryHoldTests(TransactionTestCase):
    """Test inventory hold functionality."""
    
    def setUp(self):
        self.property = Property.objects.create(
            property_code='TEST_PROP',
            property_name='Test Property',
            timezone='UTC'
        )
        self.room_type = RoomType.objects.create(
            property=self.property,
            room_type_code='DELUXE',
            room_type_name='Deluxe Room',
            base_physical_count=10,
            max_occupancy=2
        )
        self.today = date.today()
        InventoryService.preload_inventory(self.room_type, self.today, days=10)
    
    def test_create_hold_updates_held_count(self):
        """Test that creating a hold updates held_count."""
        start_date = self.today
        end_date = self.today + timedelta(days=1)
        expires_at = timezone.now() + timedelta(minutes=15)
        
        holds = InventoryService.create_hold(
            self.room_type, start_date, end_date, 3, expires_at
        )
        
        self.assertEqual(len(holds), 1)
        
        inv = InventoryCalendar.objects.get(
            room_type=self.room_type,
            stay_date=start_date
        )
        self.assertEqual(inv.held_count, 3)
    
    def test_create_hold_insufficient_inventory(self):
        """Test that hold creation fails with insufficient inventory."""
        start_date = self.today
        end_date = self.today + timedelta(days=1)
        expires_at = timezone.now() + timedelta(minutes=15)
        
        with self.assertRaises(InsufficientInventoryException):
            InventoryService.create_hold(
                self.room_type, start_date, end_date, 15, expires_at
            )
    
    def test_release_hold(self):
        """Test releasing a hold."""
        start_date = self.today
        end_date = self.today + timedelta(days=1)
        expires_at = timezone.now() + timedelta(minutes=15)
        
        holds = InventoryService.create_hold(
            self.room_type, start_date, end_date, 3, expires_at
        )
        hold = holds[0]
        
        InventoryService.release_hold(hold)
        
        inv = InventoryCalendar.objects.get(
            room_type=self.room_type,
            stay_date=start_date
        )
        self.assertEqual(inv.held_count, 0)


class InventoryAvailabilityTests(TestCase):
    """Test inventory availability checking."""
    
    def setUp(self):
        self.property = Property.objects.create(
            property_code='TEST_PROP',
            property_name='Test Property',
            timezone='UTC'
        )
        self.room_type = RoomType.objects.create(
            property=self.property,
            room_type_code='DELUXE',
            room_type_name='Deluxe Room',
            base_physical_count=10,
            max_occupancy=2
        )
        self.today = date.today()
        InventoryService.preload_inventory(self.room_type, self.today, days=10)
    
    def test_check_availability_sufficient(self):
        """Test availability check with sufficient inventory."""
        start_date = self.today
        end_date = self.today + timedelta(days=3)
        
        is_available = InventoryService.check_availability(
            self.room_type, start_date, end_date, 5
        )
        
        self.assertTrue(is_available)
    
    def test_check_availability_insufficient(self):
        """Test availability check with insufficient inventory."""
        start_date = self.today
        end_date = self.today + timedelta(days=1)
        
        is_available = InventoryService.check_availability(
            self.room_type, start_date, end_date, 15
        )
        
        self.assertFalse(is_available)
    
    def test_check_availability_after_reservation(self):
        """Test availability after making a reservation."""
        start_date = self.today
        end_date = self.today + timedelta(days=2)
        
        # Reserve 7 units
        InventoryService.reserve(self.room_type, start_date, end_date, 7)
        
        # Check availability for 4 units (should be available)
        is_available = InventoryService.check_availability(
            self.room_type, start_date, end_date, 4
        )
        self.assertTrue(is_available)
        
        # Check availability for 5 units (should NOT be available)
        is_available = InventoryService.check_availability(
            self.room_type, start_date, end_date, 5
        )
        self.assertFalse(is_available)


class InventoryConsistencyTests(TestCase):
    """Test inventory data consistency and validation."""
    
    def setUp(self):
        self.property = Property.objects.create(
            property_code='TEST_PROP',
            property_name='Test Property',
            timezone='UTC'
        )
        self.room_type = RoomType.objects.create(
            property=self.property,
            room_type_code='DELUXE',
            room_type_name='Deluxe Room',
            base_physical_count=10,
            max_occupancy=2
        )
        self.today = date.today()
    
    def test_available_count_calculation(self):
        """Test that available_count is calculated correctly."""
        inv = InventoryCalendar.objects.create(
            property=self.property,
            room_type=self.room_type,
            stay_date=self.today,
            physical_count=10,
            sold_count=3,
            held_count=2,
            ooo_count=1,
            overbooking_limit=2
        )
        
        # available = physical + overbooking - sold - held - ooo
        # available = 10 + 2 - 3 - 2 - 1 = 6
        self.assertEqual(inv.available_count, 6)
    
    def test_available_count_with_overbooking(self):
        """Test available count with overbooking."""
        inv = InventoryCalendar.objects.create(
            property=self.property,
            room_type=self.room_type,
            stay_date=self.today,
            physical_count=10,
            sold_count=10,
            held_count=0,
            ooo_count=0,
            overbooking_limit=3
        )
        
        # available = 10 + 3 - 10 - 0 - 0 = 3
        self.assertEqual(inv.available_count, 3)
    
    def test_available_count_negative_prevention(self):
        """Test that available_count doesn't go negative."""
        inv = InventoryCalendar.objects.create(
            property=self.property,
            room_type=self.room_type,
            stay_date=self.today,
            physical_count=10,
            sold_count=15,  # Over-allocated
            held_count=0,
            ooo_count=0,
            overbooking_limit=0
        )
        
        # Even with over-allocation, available should be 0 (not negative)
        self.assertEqual(inv.available_count, 0)


class InventoryEventSourcingTests(TestCase):
    """Test event sourcing and event store functionality."""
    
    def setUp(self):
        self.property = Property.objects.create(
            property_code='TEST_PROP',
            property_name='Test Property',
            timezone='UTC'
        )
        self.room_type = RoomType.objects.create(
            property=self.property,
            room_type_code='DELUXE',
            room_type_name='Deluxe Room',
            base_physical_count=10,
            max_occupancy=2
        )
        self.today = date.today()
    
    def test_events_are_created_on_reserve(self):
        """Test that events are created when reserving inventory."""
        InventoryService.preload_inventory(self.room_type, self.today, days=1)
        
        start_date = self.today
        end_date = self.today + timedelta(days=1)
        
        InventoryService.reserve(self.room_type, start_date, end_date, 2)
        
        events = InventoryEvent.objects.filter(
            room_type=self.room_type,
            event_type='RESERVED'
        )
        
        self.assertEqual(events.count(), 1)
    
    def test_event_data_contains_correct_information(self):
        """Test that event data contains correct information."""
        InventoryService.preload_inventory(self.room_type, self.today, days=1)
        
        start_date = self.today
        end_date = self.today + timedelta(days=1)
        quantity = 3
        
        InventoryService.reserve(self.room_type, start_date, end_date, quantity)
        
        event = InventoryEvent.objects.get(
            room_type=self.room_type,
            event_type='RESERVED'
        )
        
        self.assertEqual(event.event_data['quantity'], quantity)
        self.assertEqual(event.event_data['start_date'], str(start_date))
        self.assertEqual(event.event_data['end_date'], str(end_date))
