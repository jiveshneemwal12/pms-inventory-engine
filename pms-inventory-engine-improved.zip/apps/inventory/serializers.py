from rest_framework import serializers
from datetime import date, timedelta
from typing import Any

from .models import InventoryCalendar, InventoryEvent, InventoryHold, Allotment


class InventoryCalendarSerializer(serializers.ModelSerializer):
    available_count = serializers.IntegerField(read_only=True)
    status = serializers.CharField(read_only=True)
    property_code = serializers.CharField(source='property.property_code', read_only=True)
    room_type_code = serializers.CharField(source='room_type.room_type_code', read_only=True)
    
    class Meta:
        model = InventoryCalendar
        fields = [
            'id',
            'property',
            'property_code',
            'room_type',
            'room_type_code',
            'stay_date',
            'physical_count',
            'sold_count',
            'held_count',
            'ooo_count',
            'overbooking_limit',
            'available_count',
            'status',
            'version',
            'created_at',
            'updated_at',
        ]
        read_only_fields = [
            'id',
            'available_count',
            'status',
            'version',
            'created_at',
            'updated_at',
        ]


class InventoryListSerializer(serializers.ModelSerializer):
    available_count = serializers.IntegerField(read_only=True)
    status = serializers.CharField(read_only=True)
    
    class Meta:
        model = InventoryCalendar
        fields = [
            'id',
            'stay_date',
            'physical_count',
            'available_count',
            'sold_count',
            'status',
        ]


class InventoryEventSerializer(serializers.ModelSerializer):
    property_code = serializers.CharField(source='property.property_code', read_only=True)
    room_type_code = serializers.CharField(source='room_type.room_type_code', read_only=True)
    
    class Meta:
        model = InventoryEvent
        fields = [
            'id',
            'inventory',
            'property',
            'property_code',
            'room_type',
            'room_type_code',
            'stay_date',
            'event_type',
            'event_data',
            'correlation_id',
            'created_at',
        ]
        read_only_fields = [
            'id',
            'inventory',
            'property',
            'property_code',
            'room_type',
            'room_type_code',
            'stay_date',
            'event_type',
            'event_data',
            'correlation_id',
            'created_at',
        ]


class BulkInitializeSerializer(serializers.Serializer):
    room_type_id = serializers.UUIDField()
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    physical_count = serializers.IntegerField(required=False, allow_null=True)
    overbooking_limit = serializers.IntegerField(default=0, min_value=0)
    correlation_id = serializers.UUIDField(required=False, allow_null=True)
    
    def validate(self, attrs: dict[str, Any]) -> dict[str, Any]:
        start_date = attrs.get('start_date')
        end_date = attrs.get('end_date')
        
        if start_date and end_date:
            if end_date < start_date:
                raise serializers.ValidationError({
                    'end_date': 'End date must be after start date'
                })
            
            # Max 365 days at once
            days_diff = (end_date - start_date).days
            if days_diff > 365:
                raise serializers.ValidationError({
                    'end_date': 'Cannot initialize more than 365 days at once'
                })
        
        physical_count = attrs.get('physical_count')
        if physical_count is not None and physical_count < 1:
            raise serializers.ValidationError({
                'physical_count': 'Physical count must be at least 1'
            })
        
        return attrs


class BlockInventorySerializer(serializers.Serializer):
    room_type_id = serializers.UUIDField()
    stay_date = serializers.DateField()
    block_count = serializers.IntegerField(min_value=1)
    reason = serializers.CharField(max_length=255)
    correlation_id = serializers.UUIDField(required=False, allow_null=True)
    
    def validate_stay_date(self, value: date) -> date:
        if value < date.today():
            raise serializers.ValidationError("Cannot block inventory for past dates")
        return value


class ReleaseInventorySerializer(serializers.Serializer):
    room_type_id = serializers.UUIDField()
    stay_date = serializers.DateField()
    release_count = serializers.IntegerField(min_value=1)
    reason = serializers.CharField(max_length=255)
    correlation_id = serializers.UUIDField(required=False, allow_null=True)


class AdjustInventorySerializer(serializers.Serializer):
    room_type_id = serializers.UUIDField()
    stay_date = serializers.DateField()
    physical_count = serializers.IntegerField(required=False, allow_null=True, min_value=0)
    overbooking_limit = serializers.IntegerField(required=False, allow_null=True, min_value=0)
    reason = serializers.CharField(max_length=255)
    correlation_id = serializers.UUIDField(required=False, allow_null=True)
    
    def validate(self, attrs: dict[str, Any]) -> dict[str, Any]:
        physical_count = attrs.get('physical_count')
        overbooking_limit = attrs.get('overbooking_limit')
        
        if physical_count is None and overbooking_limit is None:
            raise serializers.ValidationError(
                "At least one adjustment field is required (physical_count or overbooking_limit)"
            )
        
        return attrs


class CheckAvailabilitySerializer(serializers.Serializer):
    room_type_id = serializers.UUIDField()
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    required_count = serializers.IntegerField(default=1, min_value=1)
    
    def validate(self, attrs: dict[str, Any]) -> dict[str, Any]:
        start_date = attrs.get('start_date')
        end_date = attrs.get('end_date')
        
        if start_date and end_date:
            if end_date < start_date:
                raise serializers.ValidationError({
                    'end_date': 'End date must be after start date'
                })
            
            # Max 365 days query
            days_diff = (end_date - start_date).days
            if days_diff > 365:
                raise serializers.ValidationError({
                    'end_date': 'Cannot check more than 365 days at once'
                })
        
        return attrs


class AvailabilityCalendarSerializer(serializers.Serializer):
    date = serializers.DateField()
    available_count = serializers.IntegerField()
    physical_count = serializers.IntegerField()
    sold_count = serializers.IntegerField()
    held_count = serializers.IntegerField()
    ooo_count = serializers.IntegerField()
    status = serializers.CharField()


class InventoryHoldSerializer(serializers.ModelSerializer):
    """Serializer for inventory holds"""
    property_code = serializers.CharField(source='property.property_code', read_only=True)
    room_type_code = serializers.CharField(source='room_type.room_type_code', read_only=True)
    is_active = serializers.BooleanField(read_only=True)
    
    class Meta:
        model = InventoryHold
        fields = [
            'id',
            'property',
            'property_code',
            'room_type',
            'room_type_code',
            'stay_date',
            'hold_count',
            'hold_type',
            'expires_at',
            'released_at',
            'reference_id',
            'notes',
            'is_active',
            'created_at',
        ]
        read_only_fields = ['id', 'created_at', 'released_at', 'is_active']


class CreateHoldSerializer(serializers.Serializer):
    """Serializer for creating inventory holds"""
    room_type_id = serializers.UUIDField()
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    hold_count = serializers.IntegerField(min_value=1)
    hold_type = serializers.ChoiceField(
        choices=['BOOKING_CART', 'PENDING_PAYMENT', 'MANUAL_HOLD', 'SYSTEM_HOLD'],
        default='MANUAL_HOLD'
    )
    expires_in_minutes = serializers.IntegerField(default=15, min_value=1, max_value=1440)
    reference_id = serializers.CharField(max_length=255, required=False, allow_blank=True, allow_null=True)
    notes = serializers.CharField(max_length=500, required=False, allow_blank=True)
    
    def validate(self, attrs: dict[str, Any]) -> dict[str, Any]:
        start_date = attrs.get('start_date')
        end_date = attrs.get('end_date')
        
        if start_date and end_date:
            if end_date < start_date:
                raise serializers.ValidationError({
                    'end_date': 'End date must be after start date'
                })
            
            # Max 30 days hold at once
            days_diff = (end_date - start_date).days
            if days_diff > 30:
                raise serializers.ValidationError({
                    'end_date': 'Cannot hold more than 30 days at once'
                })
        
        return attrs


class AllotmentSerializer(serializers.ModelSerializer):
    """Serializer for allotments"""
    property_code = serializers.CharField(source='property.property_code', read_only=True)
    room_type_code = serializers.CharField(source='room_type.room_type_code', read_only=True)
    remaining_rooms = serializers.IntegerField(read_only=True)
    
    class Meta:
        model = Allotment
        fields = [
            'id',
            'property',
            'property_code',
            'room_type',
            'room_type_code',
            'allotment_name',
            'allotment_type',
            'start_date',
            'end_date',
            'cutoff_date',
            'total_rooms',
            'picked_up_rooms',
            'remaining_rooms',
            'status',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'picked_up_rooms', 'remaining_rooms', 'created_at', 'updated_at']
    
    def validate(self, attrs: dict[str, Any]) -> dict[str, Any]:
        start_date = attrs.get('start_date')
        end_date = attrs.get('end_date')
        cutoff_date = attrs.get('cutoff_date')
        
        if start_date and end_date:
            if end_date <= start_date:
                raise serializers.ValidationError({
                    'end_date': 'End date must be after start date'
                })
        
        if cutoff_date and start_date:
            if cutoff_date > start_date:
                raise serializers.ValidationError({
                    'cutoff_date': 'Cutoff date must be before or on start date'
                })
        
        return attrs
