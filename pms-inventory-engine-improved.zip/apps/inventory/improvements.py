"""
Improvements and enhancements to the Inventory Management Engine.
This module contains best practices, optimizations, and robustness improvements.
"""

from datetime import datetime, timedelta
from django.db import transaction, IntegrityError
from django.db.models import F, Q, Prefetch
from django.core.cache import cache
from django.conf import settings
import uuid
import logging
from typing import List, Dict, Tuple, Optional
from .models import InventoryCalendar, InventoryEvent, InventoryHold
from apps.common.exceptions import InsufficientInventoryException, InventoryLockException

logger = logging.getLogger(__name__)

class InventoryOptimizations:
    """
    Collection of optimizations and best practices for the Inventory Engine.
    """
    
    @staticmethod
    def bulk_check_availability_optimized(room_type, date_ranges: List[Tuple], quantity: int) -> Dict[str, bool]:
        """
        Optimized bulk availability check for multiple date ranges.
        Reduces database queries by batching availability checks.
        
        Args:
            room_type: RoomType instance
            date_ranges: List of (start_date, end_date) tuples
            quantity: int - units required
            
        Returns:
            Dict mapping date_range to availability boolean
        """
        results = {}
        all_dates = set()
        
        # Collect all unique dates
        for start_date, end_date in date_ranges:
            current = start_date
            while current < end_date:
                all_dates.add(current)
                current += timedelta(days=1)
        
        # Single query to get all inventory for all dates
        inventory_map = {}
        inventories = InventoryCalendar.objects.filter(
            room_type=room_type,
            stay_date__in=all_dates
        ).values('stay_date', 'available_count')
        
        for inv in inventories:
            inventory_map[inv['stay_date']] = inv['available_count']
        
        # Check each date range
        for start_date, end_date in date_ranges:
            current = start_date
            is_available = True
            while current < end_date:
                if inventory_map.get(current, 0) < quantity:
                    is_available = False
                    break
                current += timedelta(days=1)
            results[(start_date, end_date)] = is_available
        
        return results
    
    @staticmethod
    def prefetch_inventory_with_related(room_types: List, start_date, end_date):
        """
        Optimized prefetch of inventory with related data to avoid N+1 queries.
        
        Args:
            room_types: List of RoomType instances
            start_date: datetime.date
            end_date: datetime.date
            
        Returns:
            Prefetched inventory queryset
        """
        return InventoryCalendar.objects.filter(
            room_type__in=room_types,
            stay_date__gte=start_date,
            stay_date__lt=end_date
        ).select_related('room_type', 'property').prefetch_related(
            Prefetch('room_type__inventory_calendar')
        )
    
    @staticmethod
    def adaptive_retry_strategy(max_retries: int = 3, base_delay: float = 0.1) -> List[float]:
        """
        Generate adaptive retry delays with exponential backoff and jitter.
        Reduces contention spikes during high concurrency.
        
        Args:
            max_retries: Maximum number of retries
            base_delay: Base delay in seconds
            
        Returns:
            List of delays for each retry attempt
        """
        import random
        delays = []
        for attempt in range(max_retries):
            # Exponential backoff: base_delay * (2 ** attempt)
            delay = base_delay * (2 ** attempt)
            # Add jitter (±20% of delay)
            jitter = delay * 0.2 * (random.random() - 0.5)
            delays.append(max(0, delay + jitter))
        return delays
    
    @staticmethod
    def batch_cache_invalidation(room_type, date_range: Tuple):
        """
        Efficient batch cache invalidation for a date range.
        Uses Redis pipeline to reduce network round-trips.
        
        Args:
            room_type: RoomType instance
            date_range: (start_date, end_date) tuple
        """
        start_date, end_date = date_range
        current = start_date
        cache_keys = []
        
        while current < end_date:
            # Generate cache keys for this date
            cache_key = f"inventory:{room_type.id}:{current.isoformat()}"
            range_cache_key = f"inventory:range:{room_type.id}:{start_date.isoformat()}:{end_date.isoformat()}"
            property_cache_key = f"inventory:property:{room_type.property_id}:{current.isoformat()}"
            
            cache_keys.extend([cache_key, range_cache_key, property_cache_key])
            current += timedelta(days=1)
        
        # Batch delete using cache.delete_many if available
        if hasattr(cache, 'delete_many'):
            cache.delete_many(cache_keys)
        else:
            for key in cache_keys:
                cache.delete(key)
        
        logger.debug(f"Invalidated {len(set(cache_keys))} cache keys for {room_type}")
    
    @staticmethod
    def calculate_available_count_safe(inventory: InventoryCalendar) -> int:
        """
        Safe calculation of available count with validation.
        Prevents negative availability due to data inconsistencies.
        
        Args:
            inventory: InventoryCalendar instance
            
        Returns:
            int - available count (guaranteed non-negative)
        """
        available = (
            inventory.physical_count + 
            inventory.overbooking_limit - 
            inventory.sold_count - 
            inventory.held_count - 
            inventory.ooo_count
        )
        return max(0, available)
    
    @staticmethod
    def validate_inventory_consistency(room_type, start_date, end_date) -> Dict[str, any]:
        """
        Validate inventory data consistency and detect anomalies.
        Useful for monitoring and debugging.
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            end_date: datetime.date
            
        Returns:
            Dict with consistency check results
        """
        issues = []
        current = start_date
        
        while current < end_date:
            try:
                inv = InventoryCalendar.objects.get(
                    room_type=room_type,
                    stay_date=current
                )
                
                # Check 1: Negative available count
                if inv.available_count < 0:
                    issues.append({
                        'date': current,
                        'issue': 'negative_available_count',
                        'available_count': inv.available_count
                    })
                
                # Check 2: Counts exceed physical + overbooking
                total_allocated = inv.sold_count + inv.held_count + inv.ooo_count
                max_allowed = inv.physical_count + inv.overbooking_limit
                if total_allocated > max_allowed:
                    issues.append({
                        'date': current,
                        'issue': 'over_allocation',
                        'allocated': total_allocated,
                        'max_allowed': max_allowed
                    })
                
                # Check 3: Invalid counts (negative)
                for field in ['sold_count', 'held_count', 'ooo_count']:
                    if getattr(inv, field) < 0:
                        issues.append({
                            'date': current,
                            'issue': f'negative_{field}',
                            'value': getattr(inv, field)
                        })
                
            except InventoryCalendar.DoesNotExist:
                issues.append({
                    'date': current,
                    'issue': 'missing_inventory_record'
                })
            
            current += timedelta(days=1)
        
        return {
            'is_consistent': len(issues) == 0,
            'issues': issues,
            'total_issues': len(issues)
        }
    
    @staticmethod
    def repair_inventory_from_events(room_type, start_date, end_date) -> int:
        """
        Repair inventory data by rebuilding from event log.
        Useful for fixing data inconsistencies.
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            end_date: datetime.date
            
        Returns:
            int - number of records repaired
        """
        repaired_count = 0
        current = start_date
        
        while current < end_date:
            try:
                # Get all events for this date
                events = InventoryEvent.objects.filter(
                    room_type=room_type,
                    stay_date=current
                ).order_by('created_at')
                
                # Rebuild state from events
                physical_count = room_type.base_physical_count
                sold_count = 0
                held_count = 0
                ooo_count = 0
                
                for event in events:
                    event_data = event.event_data or {}
                    
                    if event.event_type == 'PRELOADED':
                        physical_count = event_data.get('physical_count', room_type.base_physical_count)
                    elif event.event_type == 'RESERVED':
                        sold_count += event_data.get('quantity', 0)
                    elif event.event_type == 'RELEASED':
                        sold_count -= event_data.get('quantity', 0)
                    elif event.event_type == 'HELD':
                        held_count += event_data.get('quantity', 0)
                    elif event.event_type == 'HOLD_RELEASED':
                        held_count -= event_data.get('quantity', 0)
                    elif event.event_type == 'OOO_ADDED':
                        ooo_count += event_data.get('quantity', 0)
                    elif event.event_type == 'OOO_REMOVED':
                        ooo_count -= event_data.get('quantity', 0)
                
                # Ensure non-negative counts
                sold_count = max(0, sold_count)
                held_count = max(0, held_count)
                ooo_count = max(0, ooo_count)
                
                # Update or create inventory record
                inv, created = InventoryCalendar.objects.update_or_create(
                    room_type=room_type,
                    stay_date=current,
                    defaults={
                        'physical_count': physical_count,
                        'sold_count': sold_count,
                        'held_count': held_count,
                        'ooo_count': ooo_count,
                        'version': events.count()
                    }
                )
                
                if created or inv.sold_count != sold_count or inv.held_count != held_count:
                    repaired_count += 1
                    logger.info(f"Repaired inventory for {room_type} on {current}")
                
            except Exception as e:
                logger.error(f"Failed to repair inventory for {room_type} on {current}: {e}")
            
            current += timedelta(days=1)
        
        return repaired_count


class KafkaReliabilityEnhancements:
    """
    Enhancements for reliable Kafka event publishing with retry and DLQ support.
    """
    
    @staticmethod
    def publish_with_retry(topic: str, event_data: dict, max_retries: int = 3) -> bool:
        """
        Publish event to Kafka with retry logic and error handling.
        
        Args:
            topic: Kafka topic name
            event_data: Event payload
            max_retries: Maximum retry attempts
            
        Returns:
            bool - True if published successfully, False otherwise
        """
        from apps.common.kafka_utils import get_producer
        import json
        import time
        
        producer = get_producer()
        
        for attempt in range(max_retries):
            try:
                future = producer.send(
                    topic,
                    value=json.dumps(event_data).encode('utf-8')
                )
                # Wait for send to complete
                record_metadata = future.get(timeout=10)
                logger.info(f"Published event to {topic} (partition: {record_metadata.partition}, offset: {record_metadata.offset})")
                return True
            except Exception as e:
                logger.warning(f"Kafka publish attempt {attempt + 1}/{max_retries} failed: {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    # Send to DLQ
                    KafkaReliabilityEnhancements._send_to_dlq(topic, event_data, str(e))
                    return False
        
        return False
    
    @staticmethod
    def _send_to_dlq(original_topic: str, event_data: dict, error: str):
        """
        Send failed event to Dead Letter Queue (DLQ) for later inspection.
        
        Args:
            original_topic: Original topic name
            event_data: Event payload
            error: Error message
        """
        from apps.common.kafka_utils import get_producer
        import json
        
        dlq_topic = f"{original_topic}.dlq"
        dlq_event = {
            'original_topic': original_topic,
            'event_data': event_data,
            'error': error,
            'timestamp': datetime.utcnow().isoformat(),
            'correlation_id': event_data.get('correlation_id', str(uuid.uuid4()))
        }
        
        try:
            producer = get_producer()
            producer.send(dlq_topic, value=json.dumps(dlq_event).encode('utf-8'))
            producer.flush()
            logger.error(f"Event sent to DLQ: {dlq_topic}")
        except Exception as e:
            logger.critical(f"Failed to send to DLQ: {e}")


class InventoryMonitoring:
    """
    Monitoring and observability utilities for the Inventory Engine.
    """
    
    @staticmethod
    def get_inventory_metrics(room_type, start_date, end_date) -> Dict:
        """
        Calculate key metrics for inventory analysis.
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            end_date: datetime.date
            
        Returns:
            Dict with inventory metrics
        """
        inventories = InventoryCalendar.objects.filter(
            room_type=room_type,
            stay_date__gte=start_date,
            stay_date__lt=end_date
        )
        
        if not inventories.exists():
            return {}
        
        from django.db.models import Sum, Avg, Min, Max
        
        stats = inventories.aggregate(
            total_physical=Sum('physical_count'),
            total_sold=Sum('sold_count'),
            total_held=Sum('held_count'),
            total_ooo=Sum('ooo_count'),
            avg_available=Avg('available_count'),
            min_available=Min('available_count'),
            max_available=Max('available_count'),
            occupancy_rate=Avg(F('sold_count') * 100.0 / F('physical_count'), output_field=models.FloatField())
        )
        
        return {
            'date_range': f"{start_date} to {end_date}",
            'total_days': inventories.count(),
            'metrics': stats
        }
    
    @staticmethod
    def detect_anomalies(room_type, start_date, end_date, threshold: float = 0.8) -> List[Dict]:
        """
        Detect inventory anomalies (e.g., sudden spikes in holds/OOO).
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            end_date: datetime.date
            threshold: Anomaly threshold (0-1)
            
        Returns:
            List of detected anomalies
        """
        inventories = list(InventoryCalendar.objects.filter(
            room_type=room_type,
            stay_date__gte=start_date,
            stay_date__lt=end_date
        ).order_by('stay_date'))
        
        anomalies = []
        
        for i in range(1, len(inventories)):
            prev = inventories[i - 1]
            curr = inventories[i]
            
            # Check for sudden changes
            held_change = abs(curr.held_count - prev.held_count)
            ooo_change = abs(curr.ooo_count - prev.ooo_count)
            
            if held_change > prev.physical_count * threshold:
                anomalies.append({
                    'date': curr.stay_date,
                    'type': 'sudden_hold_change',
                    'previous': prev.held_count,
                    'current': curr.held_count,
                    'change': held_change
                })
            
            if ooo_change > prev.physical_count * threshold:
                anomalies.append({
                    'date': curr.stay_date,
                    'type': 'sudden_ooo_change',
                    'previous': prev.ooo_count,
                    'current': curr.ooo_count,
                    'change': ooo_change
                })
        
        return anomalies
