"""
Event projector for rebuilding read models from events.
Implements Eventual Consistency principle.
"""
from django.core.management.base import BaseCommand
from apps.inventory.models import InventoryEvent, InventoryCalendar
from apps.properties.models import RoomType


class Command(BaseCommand):
    help = 'Rebuild inventory read models from event log (Event Sourcing)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--room-type-id',
            type=str,
            help='Rebuild specific room type only',
        )
        parser.add_argument(
            '--date',
            type=str,
            help='Rebuild specific date only (YYYY-MM-DD)',
        )

    def handle(self, *args, **options):
        from datetime import datetime
        from django.db import transaction
        
        self.stdout.write(self.style.SUCCESS('Starting inventory projection...'))
        
        # Determine scope
        room_types = RoomType.objects.all()
        if options['room_type_id']:
            room_types = room_types.filter(id=options['room_type_id'])
        
        dates = None
        if options['date']:
            dates = [datetime.strptime(options['date'], '%Y-%m-%d').date()]
        
        rebuilt_count = 0
        
        with transaction.atomic():
            for room_type in room_types:
                self.stdout.write(f"Processing {room_type}...")
                
                # Get all dates with events for this room type
                event_dates = InventoryEvent.objects.filter(
                    room_type=room_type
                ).values_list('date', flat=True).distinct()
                
                if dates:
                    event_dates = [d for d in event_dates if d in dates]
                
                for date in event_dates:
                    # Get all events for this date
                    events = InventoryEvent.objects.filter(
                        room_type=room_type,
                        date=date
                    ).order_by('created_at')
                    
                    # Calculate state from events
                    total_units = room_type.total_units
                    booked_units = 0
                    
                    for event in events:
                        if event.event_type == 'PRELOADED':
                            total_units = event.metadata.get('total_units', room_type.total_units)
                        elif event.event_type == 'RESERVED':
                            booked_units += event.quantity
                        elif event.event_type == 'RELEASED':
                            booked_units += event.quantity  # quantity is negative
                        elif event.event_type == 'ADJUSTED':
                            booked_units += event.quantity
                    
                    # Update or create inventory record
                    inventory, created = InventoryCalendar.objects.update_or_create(
                        room_type=room_type,
                        date=date,
                        defaults={
                            'total_units': total_units,
                            'booked_units': max(0, booked_units),
                            'version': events.count()
                        }
                    )
                    
                    action = 'Created' if created else 'Updated'
                    self.stdout.write(
                        f"  {action} {date}: {booked_units}/{total_units} booked"
                    )
                    rebuilt_count += 1
        
        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully rebuilt {rebuilt_count} inventory records from events'
            )
        )
