"""
Kafka event schemas for inventory management.
"""
from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class InventoryInitializedEvent:
    """Event published when inventory is initialized"""
    room_type_id: str
    property_id: str
    start_date: str
    end_date: str
    physical_count: int
    records_created: int
    performed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'room_type_id': self.room_type_id,
            'property_id': self.property_id,
            'start_date': self.start_date,
            'end_date': self.end_date,
            'physical_count': self.physical_count,
            'records_created': self.records_created,
            'performed_by': self.performed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class InventoryBlockedEvent:
    """Event published when inventory is blocked"""
    inventory_id: str
    room_type_id: str
    property_id: str
    stay_date: str
    block_count: int
    new_available: int
    reason: str
    performed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'inventory_id': self.inventory_id,
            'room_type_id': self.room_type_id,
            'property_id': self.property_id,
            'stay_date': self.stay_date,
            'block_count': self.block_count,
            'new_available': self.new_available,
            'reason': self.reason,
            'performed_by': self.performed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class InventoryReleasedEvent:
    """Event published when blocked inventory is released"""
    inventory_id: str
    room_type_id: str
    property_id: str
    stay_date: str
    release_count: int
    new_available: int
    reason: str
    performed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'inventory_id': self.inventory_id,
            'room_type_id': self.room_type_id,
            'property_id': self.property_id,
            'stay_date': self.stay_date,
            'release_count': self.release_count,
            'new_available': self.new_available,
            'reason': self.reason,
            'performed_by': self.performed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class InventoryAdjustedEvent:
    """Event published when inventory is manually adjusted"""
    inventory_id: str
    room_type_id: str
    property_id: str
    stay_date: str
    adjustments: Dict[str, Any]
    new_available: int
    reason: str
    performed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'inventory_id': self.inventory_id,
            'room_type_id': self.room_type_id,
            'property_id': self.property_id,
            'stay_date': self.stay_date,
            'adjustments': self.adjustments,
            'new_available': self.new_available,
            'reason': self.reason,
            'performed_by': self.performed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class InventoryReservedEvent:
    """Event published when inventory is reserved for a booking"""
    inventory_id: str
    room_type_id: str
    property_id: str
    stay_date: str
    reserve_count: int
    new_available: int
    reservation_id: str
    performed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'inventory_id': self.inventory_id,
            'room_type_id': self.room_type_id,
            'property_id': self.property_id,
            'stay_date': self.stay_date,
            'reserve_count': self.reserve_count,
            'new_available': self.new_available,
            'reservation_id': self.reservation_id,
            'performed_by': self.performed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class InventoryConflictEvent:
    """Event published when optimistic locking conflict detected"""
    inventory_id: str
    room_type_id: str
    property_id: str
    stay_date: str
    conflict_type: str
    attempted_operation: str
    resolved: bool
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'inventory_id': self.inventory_id,
            'room_type_id': self.room_type_id,
            'property_id': self.property_id,
            'stay_date': self.stay_date,
            'conflict_type': self.conflict_type,
            'attempted_operation': self.attempted_operation,
            'resolved': self.resolved,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class InventoryHeldEvent:
    """Event published when inventory hold is created"""
    hold_id: str
    room_type_id: str
    property_id: str
    start_date: str
    end_date: str
    hold_count: int
    hold_type: str
    expires_at: str
    reference_id: str
    performed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'hold_id': self.hold_id,
            'room_type_id': self.room_type_id,
            'property_id': self.property_id,
            'start_date': self.start_date,
            'end_date': self.end_date,
            'hold_count': self.hold_count,
            'hold_type': self.hold_type,
            'expires_at': self.expires_at,
            'reference_id': self.reference_id,
            'performed_by': self.performed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class InventoryHoldReleasedEvent:
    """Event published when inventory hold is released"""
    hold_id: str
    room_type_id: str
    property_id: str
    stay_date: str
    hold_count: int
    hold_type: str
    reference_id: str
    performed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'hold_id': self.hold_id,
            'room_type_id': self.room_type_id,
            'property_id': self.property_id,
            'stay_date': self.stay_date,
            'hold_count': self.hold_count,
            'hold_type': self.hold_type,
            'reference_id': self.reference_id,
            'performed_by': self.performed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }


@dataclass
class AllotmentCreatedEvent:
    """Event published when allotment is created"""
    allotment_id: str
    property_id: str
    room_type_id: str
    allotment_name: str
    allotment_type: str
    start_date: str
    end_date: str
    total_rooms: int
    cutoff_date: str
    performed_by: str
    timestamp: str
    correlation_id: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'allotment_id': self.allotment_id,
            'property_id': self.property_id,
            'room_type_id': self.room_type_id,
            'allotment_name': self.allotment_name,
            'allotment_type': self.allotment_type,
            'start_date': self.start_date,
            'end_date': self.end_date,
            'total_rooms': self.total_rooms,
            'cutoff_date': self.cutoff_date,
            'performed_by': self.performed_by,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
        }
