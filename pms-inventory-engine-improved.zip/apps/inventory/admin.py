from django.contrib import admin
from .models import InventoryCalendar, InventoryEvent, Allotment, InventoryHold


@admin.register(InventoryCalendar)
class InventoryCalendarAdmin(admin.ModelAdmin):
    list_display = ('room_type', 'stay_date', 'physical_count', 'sold_count', 'held_count', 'ooo_count', 'available_count_display', 'status_display', 'version')
    list_filter = ('room_type__property', 'room_type', 'stay_date')
    search_fields = ('room_type__room_type_name', 'room_type__property__property_name')
    date_hierarchy = 'stay_date'
    readonly_fields = ('available_count_display', 'status_display', 'version', 'created_at', 'updated_at')
    
    fieldsets = (
        ('Basic Info', {
            'fields': ('property', 'room_type', 'stay_date')
        }),
        ('Inventory Counts', {
            'fields': ('physical_count', 'sold_count', 'held_count', 'ooo_count', 'overbooking_limit')
        }),
        ('Computed Fields', {
            'fields': ('available_count_display', 'status_display', 'version')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def available_count_display(self, obj):
        return obj.available_count
    available_count_display.short_description = 'Available Count'
    
    def status_display(self, obj):
        return obj.status
    status_display.short_description = 'Status'


@admin.register(InventoryEvent)
class InventoryEventAdmin(admin.ModelAdmin):
    list_display = ('event_type', 'room_type', 'stay_date', 'correlation_id', 'created_at')
    list_filter = ('event_type', 'room_type__property', 'room_type', 'stay_date', 'created_at')
    search_fields = ('room_type__room_type_name', 'room_type__property__property_name', 'correlation_id')
    date_hierarchy = 'created_at'
    readonly_fields = ('id', 'inventory', 'property', 'room_type', 'stay_date', 'event_type', 'event_data', 'correlation_id', 'created_at', 'updated_at')
    
    def has_add_permission(self, request):
        return False  # Events are append-only, no manual creation
    
    def has_delete_permission(self, request, obj=None):
        return False  # Events are immutable


@admin.register(Allotment)
class AllotmentAdmin(admin.ModelAdmin):
    list_display = ('allotment_name', 'property', 'room_type', 'allotment_type', 'start_date', 'end_date', 'total_rooms', 'picked_up_rooms', 'remaining_rooms_display', 'status')
    list_filter = ('status', 'allotment_type', 'property', 'room_type')
    search_fields = ('allotment_name', 'property__property_name', 'room_type__room_type_name')
    date_hierarchy = 'start_date'
    
    fieldsets = (
        ('Basic Info', {
            'fields': ('property', 'room_type', 'allotment_name', 'allotment_type')
        }),
        ('Date Range', {
            'fields': ('start_date', 'end_date', 'cutoff_date')
        }),
        ('Room Allocation', {
            'fields': ('total_rooms', 'picked_up_rooms', 'status')
        }),
    )
    
    def remaining_rooms_display(self, obj):
        return obj.remaining_rooms
    remaining_rooms_display.short_description = 'Remaining Rooms'


@admin.register(InventoryHold)
class InventoryHoldAdmin(admin.ModelAdmin):
    list_display = ('hold_type', 'property', 'room_type', 'stay_date', 'hold_count', 'expires_at', 'is_active_display', 'reference_id')
    list_filter = ('hold_type', 'property', 'room_type', 'expires_at', 'released_at')
    search_fields = ('property__property_name', 'room_type__room_type_name', 'reference_id', 'notes')
    date_hierarchy = 'expires_at'
    readonly_fields = ('is_active_display',)
    
    fieldsets = (
        ('Basic Info', {
            'fields': ('property', 'room_type', 'stay_date', 'hold_type')
        }),
        ('Hold Details', {
            'fields': ('hold_count', 'expires_at', 'released_at', 'reference_id')
        }),
        ('Additional Info', {
            'fields': ('notes',),
            'classes': ('collapse',)
        }),
    )
    
    def is_active_display(self, obj):
        return obj.is_active
    is_active_display.short_description = 'Is Active'
    is_active_display.boolean = True
