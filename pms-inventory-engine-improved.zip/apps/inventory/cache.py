"""
Cache utilities for inventory management.
"""
from django.core.cache import cache
from typing import Optional, List
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Cache TTL settings
INVENTORY_CACHE_TTL = 300  # 5 minutes
INVENTORY_RANGE_CACHE_TTL = 180  # 3 minutes


def get_inventory_cache_key(room_type_id: str, stay_date: datetime.date) -> str:
    """Generate cache key for single date inventory"""
    return f"inventory:{room_type_id}:{stay_date.isoformat()}"


def get_inventory_range_cache_key(room_type_id: str, start_date: datetime.date, end_date: datetime.date) -> str:
    """Generate cache key for date range inventory"""
    return f"inventory:range:{room_type_id}:{start_date.isoformat()}:{end_date.isoformat()}"


def get_property_inventory_cache_key(property_id: str, stay_date: datetime.date) -> str:
    """Generate cache key for property's all room types on a date"""
    return f"inventory:property:{property_id}:{stay_date.isoformat()}"


def cache_inventory(inventory_obj) -> None:
    """
    Cache inventory data.
    
    Args:
        inventory_obj: InventoryCalendar model instance
    """
    try:
        inventory_data = {
            'id': str(inventory_obj.id),
            'room_type_id': str(inventory_obj.room_type_id),
            'property_id': str(inventory_obj.property_id),
            'stay_date': inventory_obj.stay_date.isoformat(),
            'physical_count': inventory_obj.physical_count,
            'sold_count': inventory_obj.sold_count,
            'held_count': inventory_obj.held_count,
            'ooo_count': inventory_obj.ooo_count,
            'overbooking_limit': inventory_obj.overbooking_limit,
            'available_count': inventory_obj.available_count,
            'status': inventory_obj.status,
            'version': inventory_obj.version,
        }
        
        cache_key = get_inventory_cache_key(str(inventory_obj.room_type_id), inventory_obj.stay_date)
        cache.set(cache_key, inventory_data, INVENTORY_CACHE_TTL)
        
        logger.debug(f"Cached inventory for {inventory_obj.room_type} on {inventory_obj.stay_date}")
    except Exception as e:
        logger.error(f"Failed to cache inventory: {str(e)}")


def get_cached_inventory(room_type_id: str, stay_date: datetime.date) -> Optional[dict]:
    """Get cached inventory data"""
    try:
        cache_key = get_inventory_cache_key(room_type_id, stay_date)
        cached_data = cache.get(cache_key)
        if cached_data:
            logger.debug(f"Cache hit for inventory: {room_type_id} on {stay_date}")
            return cached_data
        logger.debug(f"Cache miss for inventory: {room_type_id} on {stay_date}")
        return None
    except Exception as e:
        logger.error(f"Failed to get cached inventory: {str(e)}")
        return None


def invalidate_inventory_cache(room_type, stay_date: datetime.date) -> None:
    """
    Invalidate cache entries for inventory.
    
    Args:
        room_type: RoomType model instance
        stay_date: Date to invalidate
    """
    try:
        # Invalidate single date cache
        cache_key = get_inventory_cache_key(str(room_type.id), stay_date)
        cache.delete(cache_key)
        
        # Invalidate property-level cache
        property_cache_key = get_property_inventory_cache_key(str(room_type.property_id), stay_date)
        cache.delete(property_cache_key)
        
        # Note: Range caches are harder to invalidate precisely
        # They will expire naturally or can be invalidated by pattern if needed
        
        logger.info(f"Invalidated cache for inventory: {room_type} on {stay_date}")
    except Exception as e:
        logger.error(f"Failed to invalidate inventory cache: {str(e)}")