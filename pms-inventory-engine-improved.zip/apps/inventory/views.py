from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from datetime import datetime, timedelta
from typing import Any, Dict, cast
from django.shortcuts import get_object_or_404
from django.db.models import F
from apps.properties.models import RoomType, Property
from apps.common.response import create_response
from .services import InventoryService
from .serializers import (
    BulkInitializeSerializer,
    BlockInventorySerializer,
    ReleaseInventorySerializer,
    AdjustInventorySerializer,
    CheckAvailabilitySerializer,
    InventoryCalendarSerializer,
    InventoryEventSerializer,
    InventoryHoldSerializer,
    CreateHoldSerializer,
    AllotmentSerializer,
)
from .models import InventoryCalendar, InventoryEvent, InventoryHold, Allotment
from .permissions import IsPropertyAdminOrReadOnly
from .cache import (
    cache_inventory,
    get_cached_inventory,
    invalidate_inventory_cache,
    get_inventory_range_cache_key,
    INVENTORY_RANGE_CACHE_TTL,
)
from .events import (
    InventoryHeldEvent,
    InventoryHoldReleasedEvent,
    AllotmentCreatedEvent,
)
from apps.common.kafka_utils import get_producer
import json
import uuid

import logging

logger = logging.getLogger(__name__)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def check_availability(request):
    serializer = CheckAvailabilitySerializer(data=request.data)
    if not serializer.is_valid():
        return create_response(
            status_type='error',
            message='Validation failed',
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        logger.info("Checking availability")
        validated_data = cast(Dict[str, Any], serializer.validated_data)
        room_type = get_object_or_404(RoomType, id=validated_data['room_type_id'])
        start_date = validated_data['start_date']
        end_date = validated_data['end_date']
        quantity = validated_data['required_count']
        logger.info(f"Room Type: {room_type}, Start Date: {start_date}, End Date: {end_date}, Quantity: {quantity}")
        from django.core.cache import cache
        cache_key = get_inventory_range_cache_key(str(room_type.id), start_date, end_date)
        cached_result = cache.get(cache_key)
        logger.info("Cache key generated: %s", cache_key)
        if cached_result is not None:
            is_available = cached_result
        else:
            is_available = InventoryService.check_availability(
                room_type=room_type,
                start_date=start_date,
                end_date=end_date,
                quantity=quantity
            )
            cache.set(cache_key, is_available, INVENTORY_RANGE_CACHE_TTL)
        
        return create_response(
            status_type='success',
            message='Availability checked successfully',
            data={
                'available': is_available,
                'room_type_id': str(room_type.id),
                'room_type_code': room_type.room_type_code,
                'start_date': str(start_date),
                'end_date': str(end_date),
                'quantity': quantity
            },
            http_status=status.HTTP_200_OK
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to check availability',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsPropertyAdminOrReadOnly])
def bulk_initialize_inventory(request):
    serializer = BulkInitializeSerializer(data=request.data)
    if not serializer.is_valid():
        return create_response(
            status_type='error',
            message='Validation failed',
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        validated_data = cast(Dict[str, Any], serializer.validated_data)
        room_type = get_object_or_404(RoomType, id=validated_data['room_type_id'])
        
        start_date = validated_data['start_date']
        end_date = validated_data['end_date']
        
        created_count = InventoryService.bulk_initialize(
            room_type=room_type,
            start_date=start_date,
            end_date=end_date,
            physical_count=validated_data['physical_count'],
            overbooking_limit=validated_data.get('overbooking_limit', 0),
            user=request.user
        )
        
        current = start_date
        while current < end_date:
            invalidate_inventory_cache(room_type, current)
            current += timedelta(days=1)
        
        return create_response(
            status_type='success',
            message=f'Successfully initialized {created_count} inventory records',
            data={
                'created_count': created_count,
                'room_type_id': str(room_type.id),
                'room_type_code': room_type.room_type_code,
                'start_date': str(start_date),
                'end_date': str(end_date),
            },
            http_status=status.HTTP_201_CREATED
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to initialize inventory',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsPropertyAdminOrReadOnly])
def block_inventory(request):
    serializer = BlockInventorySerializer(data=request.data)
    if not serializer.is_valid():
        return create_response(
            status_type='error',
            message='Validation failed',
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        validated_data = cast(Dict[str, Any], serializer.validated_data)
        room_type = get_object_or_404(RoomType, id=validated_data['room_type_id'])
        
        stay_date = validated_data['stay_date']
        
        InventoryService.block_inventory(
            room_type=room_type,
            stay_date=stay_date,
            block_count=validated_data['block_count'],
            reason=validated_data.get('reason', 'Manual block'),
            user=request.user
        )
        
        invalidate_inventory_cache(room_type, stay_date)
        
        return create_response(
            status_type='success',
            message='Inventory blocked successfully',
            data={
                'room_type_id': str(room_type.id),
                'stay_date': str(stay_date),
                'block_count': validated_data['block_count'],
            },
            http_status=status.HTTP_200_OK
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to block inventory',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsPropertyAdminOrReadOnly])
def release_inventory(request):
    serializer = ReleaseInventorySerializer(data=request.data)
    logger.info("Data validation started for release_inventory")
    if not serializer.is_valid():
        return create_response(
            status_type='error',
            message='Validation failed',
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        logger.info("Data validated successfully for release_inventory")
        validated_data = cast(Dict[str, Any], serializer.validated_data)
        room_type = get_object_or_404(RoomType, id=validated_data['room_type_id'])
        
        stay_date = validated_data['stay_date']
        logger.info(f"Releasing inventory for Room Type: {room_type}, Stay Date: {stay_date}, Release Count: {validated_data['release_count']}")
        InventoryService.release_inventory(
            room_type=room_type,
            stay_date=stay_date,
            release_count=validated_data['release_count'],
            user=request.user
        )
        
        invalidate_inventory_cache(room_type, stay_date)
        
        return create_response(
            status_type='success',
            message='Inventory released successfully',
            data={
                'room_type_id': str(room_type.id),
                'stay_date': str(stay_date),
                'release_count': validated_data['release_count'],
            },
            http_status=status.HTTP_200_OK
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to release inventory',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsPropertyAdminOrReadOnly])
def adjust_inventory(request):
    serializer = AdjustInventorySerializer(data=request.data)
    logger.info("Data validation started for adjust_inventory")
    if not serializer.is_valid():
        return create_response(
            status_type='error',
            message='Validation failed',
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        logger.info("Data validated successfully for adjust_inventory")
        validated_data = cast(Dict[str, Any], serializer.validated_data)
        room_type = get_object_or_404(RoomType, id=validated_data['room_type_id'])
        
        stay_date = validated_data['stay_date']
        logger.info(f"Adjusting inventory for Room Type: {room_type}, Stay Date: {stay_date}, Physical Count: {validated_data.get('physical_count')}, Overbooking Limit: {validated_data.get('overbooking_limit')}")
        InventoryService.adjust_inventory(
            room_type=room_type,
            stay_date=stay_date,
            physical_count=validated_data.get('physical_count'),
            overbooking_limit=validated_data.get('overbooking_limit'),
            reason=validated_data.get('reason', 'Manual adjustment'),
            user=request.user
        )
        
        # Get updated inventory to return actual values
        inventory = InventoryCalendar.objects.get(
            room_type=room_type,
            stay_date=stay_date
        )
        
        invalidate_inventory_cache(room_type, stay_date)
        logger.info("Inventory adjusted and cache invalidated for Room Type: %s, Stay Date: %s", room_type, stay_date)
        return create_response(
            status_type='success',
            message='Inventory adjusted successfully',
            data={
                'room_type_id': str(room_type.id),
                'stay_date': str(stay_date),
                'physical_count': inventory.physical_count,
                'overbooking_limit': inventory.overbooking_limit,
                'sold_count': inventory.sold_count,
                'available_count': inventory.available_count,
            },
            http_status=status.HTTP_200_OK
        )
        
    except Exception as e:
        logger.error("Failed to adjust inventory: %s", e)
        return create_response(
            status_type='error',
            message='Failed to adjust inventory',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_availability_calendar(request):
    try:
        room_type_id = request.query_params.get('room_type_id')
        start_date = datetime.strptime(request.query_params.get('start_date'), '%Y-%m-%d').date()
        end_date = datetime.strptime(request.query_params.get('end_date'), '%Y-%m-%d').date()
        
        if not room_type_id:
            return create_response(
                status_type='error',
                message='room_type_id is required',
                errors={'room_type_id': 'This field is required'},
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        room_type = get_object_or_404(RoomType, id=room_type_id)
        
        # Generate date range
        dates = []
        current = start_date
        while current <= end_date:
            dates.append(current)
            current += timedelta(days=1)
        
        # Try to get from cache first
        from django.core.cache import cache
        cache_key = get_inventory_range_cache_key(str(room_type.id), start_date, end_date)
        cached_data = cache.get(cache_key)
        
        if cached_data:
            serializer_data = cached_data
        else:
            # Fetch inventory records from database
            inventory_records = InventoryCalendar.objects.filter(
                room_type=room_type,
                stay_date__in=dates
            ).order_by('stay_date')
            
            serializer = InventoryCalendarSerializer(inventory_records, many=True)
            serializer_data = serializer.data
            
            # Cache the result for 3 minutes
            cache.set(cache_key, serializer_data, INVENTORY_RANGE_CACHE_TTL)
        
        return create_response(
            status_type='success',
            message='Calendar retrieved successfully',
            data={
                'room_type_id': str(room_type.id),
                'room_type_code': room_type.room_type_code,
                'start_date': str(start_date),
                'end_date': str(end_date),
                'records': serializer_data
            },
            http_status=status.HTTP_200_OK
        )
        
    except ValueError as e:
        return create_response(
            status_type='error',
            message='Invalid date format',
            errors={'detail': 'Use YYYY-MM-DD format'},
            http_status=status.HTTP_400_BAD_REQUEST
        )
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to retrieve calendar',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_inventory_events(request):
    try:
        room_type_id = request.query_params.get('room_type_id')
        start_date_str = request.query_params.get('start_date')
        end_date_str = request.query_params.get('end_date')
        event_type = request.query_params.get('event_type')
        correlation_id = request.query_params.get('correlation_id')
        
        # Base queryset with select_related for optimization
        events = InventoryEvent.objects.select_related(
            'property', 'room_type', 'inventory'
        ).order_by('-created_at')
        
        # Apply filters
        if room_type_id:
            events = events.filter(room_type_id=room_type_id)
        
        if start_date_str and end_date_str:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
            events = events.filter(stay_date__gte=start_date, stay_date__lte=end_date)
        elif start_date_str:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            events = events.filter(stay_date=start_date)
        
        if event_type:
            events = events.filter(event_type=event_type)
        
        if correlation_id:
            events = events.filter(correlation_id=correlation_id)
        
        # Paginate (limit to 100 records)
        events = events[:100]
        
        serializer = InventoryEventSerializer(events, many=True)
        
        return create_response(
            status_type='success',
            message='Events retrieved successfully',
            data={
                'count': len(serializer.data),
                'events': serializer.data
            },
            http_status=status.HTTP_200_OK
        )
        
    except ValueError as e:
        return create_response(
            status_type='error',
            message='Invalid date format',
            errors={'detail': 'Use YYYY-MM-DD format'},
            http_status=status.HTTP_400_BAD_REQUEST
        )
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to retrieve events',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_property_inventory(request, property_id):
    """Get all inventory for a property with date range"""
    try:
        start_date_str = request.query_params.get('start_date')
        end_date_str = request.query_params.get('end_date')
        
        if not start_date_str or not end_date_str:
            return create_response(
                status_type='error',
                message='start_date and end_date are required',
                errors={'detail': 'Both start_date and end_date query parameters are required'},
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
        
        property_obj = get_object_or_404(Property, id=property_id)
        
        # Try cache first for property-level view
        from django.core.cache import cache
        cache_key = f"property_inventory:{property_id}:{start_date}:{end_date}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            return create_response(
                status_type='success',
                message='Property inventory retrieved successfully (cached)',
                data=cached_data,
                http_status=status.HTTP_200_OK
            )
        
        # Get all room types for this property
        room_types = RoomType.objects.filter(property=property_obj)
        
        # Fetch inventory for all room types in date range
        inventory_records = InventoryCalendar.objects.filter(
            property=property_obj,
            stay_date__gte=start_date,
            stay_date__lte=end_date
        ).select_related('room_type').order_by('room_type', 'stay_date')
        
        # Group by room type
        inventory_by_room_type = {}
        for record in inventory_records:
            room_type_id = str(record.room_type.id)
            if room_type_id not in inventory_by_room_type:
                inventory_by_room_type[room_type_id] = {
                    'room_type_id': room_type_id,
                    'room_type_code': record.room_type.room_type_code,
                    'room_type_name': record.room_type.room_type_name,
                    'records': []
                }
            
            inventory_by_room_type[room_type_id]['records'].append({
                'id': str(record.id),
                'stay_date': str(record.stay_date),
                'physical_count': record.physical_count,
                'sold_count': record.sold_count,
                'held_count': record.held_count,
                'ooo_count': record.ooo_count,
                'overbooking_limit': record.overbooking_limit,
                'available_count': record.available_count,
                'status': record.status,
                'version': record.version,
            })
        
        response_data = {
            'property_id': str(property_obj.id),
            'property_code': property_obj.property_code,
            'start_date': str(start_date),
            'end_date': str(end_date),
            'room_types': list(inventory_by_room_type.values())
        }
        
        # Cache for 3 minutes (same as inventory range cache)
        cache.set(cache_key, response_data, INVENTORY_RANGE_CACHE_TTL)
        
        return create_response(
            status_type='success',
            message='Property inventory retrieved successfully',
            data=response_data,
            http_status=status.HTTP_200_OK
        )
        
    except ValueError:
        return create_response(
            status_type='error',
            message='Invalid date format',
            errors={'detail': 'Use YYYY-MM-DD format'},
            http_status=status.HTTP_400_BAD_REQUEST
        )
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to retrieve property inventory',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_room_type_inventory(request, property_id, room_type_id):
    """Get specific room type inventory for a property with date range"""
    try:
        start_date_str = request.query_params.get('start_date')
        end_date_str = request.query_params.get('end_date')
        
        if not start_date_str or not end_date_str:
            return create_response(
                status_type='error',
                message='start_date and end_date are required',
                errors={'detail': 'Both start_date and end_date query parameters are required'},
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
        
        property_obj = get_object_or_404(Property, id=property_id)
        room_type = get_object_or_404(RoomType, id=room_type_id, property=property_obj)
        
        # Try cache first
        from django.core.cache import cache
        cache_key = f"room_type_inventory:{room_type_id}:{start_date}:{end_date}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            return create_response(
                status_type='success',
                message='Room type inventory retrieved successfully (cached)',
                data=cached_data,
                http_status=status.HTTP_200_OK
            )
        
        # Fetch inventory for this specific room type in date range
        inventory_records = InventoryCalendar.objects.filter(
            property=property_obj,
            room_type=room_type,
            stay_date__gte=start_date,
            stay_date__lte=end_date
        ).order_by('stay_date')
        
        serializer = InventoryCalendarSerializer(inventory_records, many=True)
        
        response_data = {
            'property_id': str(property_obj.id),
            'property_code': property_obj.property_code,
            'room_type_id': str(room_type.id),
            'room_type_code': room_type.room_type_code,
            'room_type_name': room_type.room_type_name,
            'start_date': str(start_date),
            'end_date': str(end_date),
            'records': serializer.data
        }
        
        # Cache for 3 minutes
        cache.set(cache_key, response_data, INVENTORY_RANGE_CACHE_TTL)
        
        return create_response(
            status_type='success',
            message='Room type inventory retrieved successfully',
            data=response_data,
            http_status=status.HTTP_200_OK
        )
        
    except ValueError:
        return create_response(
            status_type='error',
            message='Invalid date format',
            errors={'detail': 'Use YYYY-MM-DD format'},
            http_status=status.HTTP_400_BAD_REQUEST
        )
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to retrieve room type inventory',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_hold(request):
    """Create temporary inventory hold"""
    serializer = CreateHoldSerializer(data=request.data)
    if not serializer.is_valid():
        return create_response(
            status_type='error',
            message='Validation failed',
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        from django.utils import timezone
        validated_data = cast(Dict[str, Any], serializer.validated_data)
        room_type = get_object_or_404(RoomType, id=validated_data['room_type_id'])
        
        start_date = validated_data['start_date']
        end_date = validated_data['end_date']
        hold_count = validated_data['hold_count']
        reference_id = validated_data.get('reference_id')
        
        # Check for existing active holds with same reference_id (idempotency)
        if reference_id:
            existing_holds = InventoryHold.objects.filter(
                reference_id=reference_id,
                room_type=room_type,
                stay_date__gte=start_date,
                stay_date__lt=end_date,
                released_at__isnull=True
            ).order_by('stay_date')
            
            # If active holds exist for this reference_id, return them instead of creating duplicates
            if existing_holds.exists():
                # Check if all expected dates are covered
                existing_dates = set(existing_holds.values_list('stay_date', flat=True))
                expected_dates = set()
                current = start_date
                while current < end_date:
                    expected_dates.add(current)
                    current += timedelta(days=1)
                
                # If all dates are covered, return existing holds
                if expected_dates == existing_dates:
                    serializer_response = InventoryHoldSerializer(existing_holds, many=True)
                    return create_response(
                        status_type='success',
                        message=f'Holds already exist for reference_id: {reference_id}',
                        data={
                            'holds': serializer_response.data,
                            'expires_at': existing_holds.first().expires_at.isoformat() if existing_holds.first() else None,
                            'note': 'Returning existing holds (idempotent response)'
                        },
                        http_status=status.HTTP_200_OK
                    )
        
        # Check availability first
        is_available = InventoryService.check_availability(
            room_type=room_type,
            start_date=start_date,
            end_date=end_date,
            quantity=hold_count
        )
        
        if not is_available:
            return create_response(
                status_type='error',
                message='Insufficient inventory to create hold',
                errors={'detail': 'Not enough inventory available for the requested dates'},
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        # Calculate expiry time
        expires_in_minutes = validated_data.get('expires_in_minutes', 15)
        expires_at = timezone.now() + timedelta(minutes=expires_in_minutes)
        
        # Create holds for each date in range
        current_date = start_date
        created_holds = []
        
        while current_date < end_date:
            hold = InventoryHold.objects.create(
                property=room_type.property,
                room_type=room_type,
                stay_date=current_date,
                hold_count=hold_count,
                hold_type=validated_data.get('hold_type', 'MANUAL_HOLD'),
                expires_at=expires_at,
                reference_id=validated_data.get('reference_id'),
                notes=validated_data.get('notes', '')
            )
            created_holds.append(hold)
            
            # Update inventory held_count
            InventoryCalendar.objects.filter(
                room_type=room_type,
                stay_date=current_date
            ).update(
                held_count=F('held_count') + hold_count,
                version=F('version') + 1
            )
            
            # Invalidate cache (per-date and property-level)
            invalidate_inventory_cache(room_type, current_date)
            
            current_date += timedelta(days=1)
        
        # Publish Kafka event
        try:
            correlation_id = str(uuid.uuid4())
            event = InventoryHeldEvent(
                hold_id=str(created_holds[0].id) if created_holds else '',
                room_type_id=str(room_type.id),
                property_id=str(room_type.property.id),
                start_date=str(start_date),
                end_date=str(end_date),
                hold_count=hold_count,
                hold_type=validated_data.get('hold_type', 'MANUAL_HOLD'),
                expires_at=expires_at.isoformat(),
                reference_id=validated_data.get('reference_id', ''),
                performed_by=request.user.email,
                timestamp=timezone.now().isoformat(),
                correlation_id=correlation_id,
            )
            producer = get_producer()
            producer.send(
                'inventory.hold.created',
                value=json.dumps(event.to_dict()).encode('utf-8')
            )
            producer.flush()
        except Exception as kafka_error:
            logger.error(f"Failed to publish InventoryHeldEvent: {kafka_error}")
        
        serializer = InventoryHoldSerializer(created_holds, many=True)
        
        return create_response(
            status_type='success',
            message=f'Successfully created {len(created_holds)} holds',
            data={
                'holds': serializer.data,
                'expires_at': expires_at.isoformat()
            },
            http_status=status.HTTP_201_CREATED
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to create hold',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def release_hold(request, hold_id):
    """Release a specific inventory hold"""
    try:
        from django.utils import timezone
        
        hold = get_object_or_404(InventoryHold, id=hold_id)
        
        if hold.released_at is not None:
            return create_response(
                status_type='error',
                message='Hold already released',
                errors={'detail': 'This hold has already been released'},
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        # Mark as released
        hold.released_at = timezone.now()
        hold.save()
        
        # Update inventory held_count
        InventoryCalendar.objects.filter(
            room_type=hold.room_type,
            stay_date=hold.stay_date
        ).update(
            held_count=F('held_count') - hold.hold_count,
            version=F('version') + 1
        )
        
        # Invalidate cache (per-date and property-level)
        invalidate_inventory_cache(hold.room_type, hold.stay_date)
        
        # Publish Kafka event
        try:
            correlation_id = str(uuid.uuid4())
            event = InventoryHoldReleasedEvent(
                hold_id=str(hold.id),
                room_type_id=str(hold.room_type.id),
                property_id=str(hold.property.id),
                stay_date=str(hold.stay_date),
                hold_count=hold.hold_count,
                hold_type=hold.hold_type,
                reference_id=hold.reference_id or '',
                performed_by=request.user.email,
                timestamp=timezone.now().isoformat(),
                correlation_id=correlation_id,
            )
            producer = get_producer()
            producer.send(
                'inventory.hold.released',
                value=json.dumps(event.to_dict()).encode('utf-8')
            )
            producer.flush()
        except Exception as kafka_error:
            logger.error(f"Failed to publish InventoryHoldReleasedEvent: {kafka_error}")
        
        return create_response(
            status_type='success',
            message='Hold released successfully',
            data={
                'hold_id': str(hold.id),
                'released_at': hold.released_at.isoformat() if hold.released_at else None
            },
            http_status=status.HTTP_200_OK
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to release hold',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def release_holds_by_reference(request, reference_id):
    """Release all holds with a specific reference_id (e.g., cart ID)"""
    try:
        from django.utils import timezone
        
        # Find all active holds with this reference_id
        holds = InventoryHold.objects.filter(
            reference_id=reference_id,
            released_at__isnull=True
        )
        
        if not holds.exists():
            return create_response(
                status_type='error',
                message='No active holds found',
                errors={'detail': f'No active holds found with reference_id: {reference_id}'},
                http_status=status.HTTP_404_NOT_FOUND
            )
        
        released_count = 0
        released_holds = []
        
        for hold in holds:
            # Mark as released
            hold.released_at = timezone.now()
            hold.save()
            
            # Update inventory held_count
            InventoryCalendar.objects.filter(
                room_type=hold.room_type,
                stay_date=hold.stay_date
            ).update(
                held_count=F('held_count') - hold.hold_count,
                version=F('version') + 1
            )
            
            # Invalidate cache
            invalidate_inventory_cache(hold.room_type, hold.stay_date)
            
            # Publish Kafka event for each hold
            try:
                correlation_id = str(uuid.uuid4())
                event = InventoryHoldReleasedEvent(
                    hold_id=str(hold.id),
                    room_type_id=str(hold.room_type.id),
                    property_id=str(hold.property.id),
                    stay_date=str(hold.stay_date),
                    hold_count=hold.hold_count,
                    hold_type=hold.hold_type,
                    reference_id=hold.reference_id or '',
                    performed_by=request.user.email,
                    timestamp=timezone.now().isoformat(),
                    correlation_id=correlation_id,
                )
                producer = get_producer()
                producer.send(
                    'inventory.hold.released',
                    value=json.dumps(event.to_dict()).encode('utf-8')
                )
                producer.flush()
            except Exception as kafka_error:
                logger.error(f"Failed to publish InventoryHoldReleasedEvent: {kafka_error}")
            
            released_holds.append({
                'hold_id': str(hold.id),
                'stay_date': str(hold.stay_date),
                'released_at': hold.released_at.isoformat() if hold.released_at else None
            })
            released_count += 1
        
        return create_response(
            status_type='success',
            message=f'Successfully released {released_count} holds',
            data={
                'reference_id': reference_id,
                'released_count': released_count,
                'holds': released_holds
            },
            http_status=status.HTTP_200_OK
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to release holds',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated, IsPropertyAdminOrReadOnly])
def create_allotment(request):
    """Create allotment for contracts/groups"""
    serializer = AllotmentSerializer(data=request.data)
    if not serializer.is_valid():
        return create_response(
            status_type='error',
            message='Validation failed',
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        from django.utils import timezone
        allotment = cast(Allotment, serializer.save())
        
        # Publish Kafka event
        try:
            correlation_id = str(uuid.uuid4())
            event = AllotmentCreatedEvent(
                allotment_id=str(allotment.id),
                property_id=str(allotment.property.id),
                room_type_id=str(allotment.room_type.id),
                allotment_name=allotment.allotment_name,
                allotment_type=allotment.allotment_type,
                start_date=str(allotment.start_date),
                end_date=str(allotment.end_date),
                total_rooms=allotment.total_rooms,
                cutoff_date=str(allotment.cutoff_date),
                performed_by=request.user.email,
                timestamp=timezone.now().isoformat(),
                correlation_id=correlation_id,
            )
            producer = get_producer()
            producer.send(
                'inventory.allotment.created',
                value=json.dumps(event.to_dict()).encode('utf-8')
            )
            producer.flush()
        except Exception as kafka_error:
            logger.error(f"Failed to publish AllotmentCreatedEvent: {kafka_error}")
        
        return create_response(
            status_type='success',
            message='Allotment created successfully',
            data=AllotmentSerializer(allotment).data,
            http_status=status.HTTP_201_CREATED
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to create allotment',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_allotment(request, allotment_id):
    """Get allotment details"""
    try:
        allotment = get_object_or_404(Allotment, id=allotment_id)
        serializer = AllotmentSerializer(allotment)
        
        return create_response(
            status_type='success',
            message='Allotment retrieved successfully',
            data=serializer.data,
            http_status=status.HTTP_200_OK
        )
        
    except Exception as e:
        return create_response(
            status_type='error',
            message='Failed to retrieve allotment',
            errors={'detail': str(e)},
            http_status=status.HTTP_400_BAD_REQUEST
        )
