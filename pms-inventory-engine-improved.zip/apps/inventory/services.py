from datetime import datetime, timedelta
from django.db import transaction, IntegrityError
from django.db.models import F
from django.conf import settings
import uuid
import hashlib
import json
from apps.common.exceptions import InsufficientInventoryException, InventoryLockException
from apps.common.kafka_utils import get_producer
from .models import InventoryCalendar, InventoryEvent, InventoryHold
from .events import (
    InventoryInitializedEvent,
    InventoryBlockedEvent,
    InventoryReleasedEvent,
    InventoryAdjustedEvent,
    InventoryReservedEvent,
)


class InventoryService:
    """
    Service for managing inventory operations.
    RULES:
    - All writes inside transaction.atomic
    - Use select_for_update
    - No async writes
    """
    
    @staticmethod
    def check_availability(room_type, start_date, end_date, quantity):
        """
        Check if sufficient inventory is available for the date range.
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            end_date: datetime.date (exclusive)
            quantity: int - number of units required
            
        Returns:
            bool: True if available, False otherwise
        """
        # Generate date range (end_date is exclusive)
        current_date = start_date
        dates = []
        while current_date < end_date:
            dates.append(current_date)
            current_date += timedelta(days=1)
        
        # Check each date
        for date in dates:
            try:
                inventory = InventoryCalendar.objects.get(
                    room_type=room_type,
                    stay_date=date
                )
                if inventory.available_count < quantity:
                    return False
            except InventoryCalendar.DoesNotExist:
                # No inventory record means no availability
                return False
        
        return True
    
    @staticmethod
    def _generate_idempotency_key(room_type_id, date, event_type, correlation_id):
        """
        Generate idempotency key for an event.
        Ensures same operation can be retried safely.
        """
        key_string = f"{room_type_id}:{date}:{event_type}:{correlation_id}"
        return hashlib.sha256(key_string.encode()).hexdigest()
    
    @staticmethod
    @transaction.atomic
    def reserve(room_type, start_date, end_date, quantity, correlation_id=None, reservation_id=None, triggered_by='system'):
        """
        Reserve inventory for a date range using Event Sourcing and Optimistic Locking.
        Idempotent - Safe to retry with same correlation_id.
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            end_date: datetime.date (exclusive)
            quantity: int - number of units to reserve
            correlation_id: UUID - for idempotency (optional, will generate if not provided)
            reservation_id: UUID - reservation reference (optional)
            triggered_by: str - who triggered this operation
            
        Returns:
            list of InventoryEvent instances
            
        Raises:
            InsufficientInventoryException: If not enough inventory
            InventoryLockException: If optimistic lock fails (concurrent modification)
        """
        if correlation_id is None:
            correlation_id = uuid.uuid4()
        
        # Generate date range
        current_date = start_date
        dates = []
        while current_date < end_date:
            dates.append(current_date)
            current_date += timedelta(days=1)
        
        # Check availability first (read-only check)
        inventory_records = InventoryCalendar.objects.filter(
            room_type=room_type,
            stay_date__in=dates
        ).select_related('room_type')
        
        if len(inventory_records) != len(dates):
            raise InsufficientInventoryException("Inventory not available for all dates")
        
        # Pre-check availability
        for inventory in inventory_records:
            if inventory.available_count < quantity:
                raise InsufficientInventoryException(
                    f"Insufficient inventory on {inventory.stay_date}. Available: {inventory.available_count}, Required: {quantity}"
                )
        
        # Create immutable events (Event Sourcing)
        created_events = []
        for date in dates:
            idempotency_key = InventoryService._generate_idempotency_key(
                room_type.id, date, 'RESERVED', correlation_id
            )
            
            try:
                event = InventoryEvent.objects.create(
                    property=room_type.property,
                    room_type=room_type,
                    stay_date=date,
                    event_type='RESERVED',
                    event_data={
                        'quantity': quantity,
                        'start_date': str(start_date),
                        'end_date': str(end_date),
                        'reservation_id': str(reservation_id) if reservation_id else None,
                        'triggered_by': triggered_by
                    },
                    correlation_id=correlation_id
                )
                created_events.append(event)
            except IntegrityError:
                # Event already exists (idempotency) - skip
                continue
        
        # Update read model with optimistic locking
        for date in dates:
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    inventory = InventoryCalendar.objects.get(
                        room_type=room_type,
                        stay_date=date
                    )
                    current_version = inventory.version
                    
                    # Optimistic lock: update only if version hasn't changed
                    updated = InventoryCalendar.objects.filter(
                        id=inventory.id,
                        version=current_version
                    ).update(
                        sold_count=F('sold_count') + quantity,
                        version=F('version') + 1
                    )
                    
                    if updated == 0:
                        if attempt < max_retries - 1:
                            continue  # Retry
                        raise InventoryLockException(
                            f"Optimistic lock failed for {date}. Concurrent modification detected."
                        )
                    break  # Success
                except InventoryCalendar.DoesNotExist:
                    raise InsufficientInventoryException(f"Inventory not found for {date}")
        
        return created_events
    
    @staticmethod
    @transaction.atomic
    def release(room_type, start_date, end_date, quantity, correlation_id=None, reservation_id=None, triggered_by='system'):
        """
        Release inventory for a date range using Event Sourcing and Optimistic Locking.
        Idempotent - Safe to retry with same correlation_id.
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            end_date: datetime.date (exclusive)
            quantity: int - number of units to release
            correlation_id: UUID - for idempotency (optional)
            reservation_id: UUID - reservation reference (optional)
            triggered_by: str - who triggered this operation
            
        Returns:
            list of InventoryEvent instances
        """
        if correlation_id is None:
            correlation_id = uuid.uuid4()
        
        # Generate date range
        current_date = start_date
        dates = []
        while current_date < end_date:
            dates.append(current_date)
            current_date += timedelta(days=1)
        
        # Create immutable events (Event Sourcing)
        created_events = []
        for date in dates:
            idempotency_key = InventoryService._generate_idempotency_key(
                room_type.id, date, 'RELEASED', correlation_id
            )
            
            try:
                event = InventoryEvent.objects.create(
                    property=room_type.property,
                    room_type=room_type,
                    stay_date=date,
                    event_type='RELEASED',
                    event_data={
                        'quantity': quantity,
                        'start_date': str(start_date),
                        'end_date': str(end_date),
                        'reservation_id': str(reservation_id) if reservation_id else None,
                        'triggered_by': triggered_by
                    },
                    correlation_id=correlation_id
                )
                created_events.append(event)
            except IntegrityError:
                # Event already exists (idempotency) - skip
                continue
        
        # Update read model with optimistic locking
        for date in dates:
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    inventory = InventoryCalendar.objects.get(
                        room_type=room_type,
                        stay_date=date
                    )
                    current_version = inventory.version
                    
                    # Optimistic lock: update only if version hasn't changed
                    updated = InventoryCalendar.objects.filter(
                        id=inventory.id,
                        version=current_version
                    ).update(
                        sold_count=F('sold_count') - quantity,
                        version=F('version') + 1
                    )
                    
                    if updated == 0:
                        if attempt < max_retries - 1:
                            continue  # Retry
                        raise InventoryLockException(
                            f"Optimistic lock failed for {date}. Concurrent modification detected."
                        )
                    break  # Success
                except InventoryCalendar.DoesNotExist:
                    # Inventory might not exist yet - skip
                    continue
        
        return created_events
    
    @staticmethod
    @transaction.atomic
    def preload_inventory(room_type, start_date, days=365, correlation_id=None, triggered_by='system'):
        """
        Preload inventory calendar for a room type with Event Sourcing.
        Idempotent - Safe to retry with same correlation_id.
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            days: int - number of days to preload
            correlation_id: UUID - for idempotency
            triggered_by: str - who triggered this operation
            
        Returns:
            list of InventoryEvent instances
        """
        if correlation_id is None:
            correlation_id = uuid.uuid4()
        
        records_to_create = []
        events_to_create = []
        current_date = start_date
        
        for _ in range(days):
            # Check if record already exists
            if not InventoryCalendar.objects.filter(
                room_type=room_type, 
                stay_date=current_date
            ).exists():
                records_to_create.append(
                    InventoryCalendar(
                        property=room_type.property,
                        room_type=room_type,
                        stay_date=current_date,
                        physical_count=room_type.base_physical_count,
                        sold_count=0,
                        version=1
                    )
                )
                
                # Create preload event
                idempotency_key = InventoryService._generate_idempotency_key(
                    room_type.id, current_date, 'PRELOADED', correlation_id
                )
                events_to_create.append(
                    InventoryEvent(
                        property=room_type.property,
                        room_type=room_type,
                        stay_date=current_date,
                        event_type='PRELOADED',
                        event_data={
                            'physical_count': room_type.base_physical_count,
                            'preload_days': days,
                            'triggered_by': triggered_by
                        },
                        correlation_id=correlation_id
                    )
                )
            current_date += timedelta(days=1)
        
        # Bulk create with idempotency
        if records_to_create:
            InventoryCalendar.objects.bulk_create(records_to_create, ignore_conflicts=True)
        
        created_events = []
        if events_to_create:
            for event in events_to_create:
                try:
                    event.save()
                    created_events.append(event)
                except IntegrityError:
                    # Event already exists (idempotency) - skip
                    continue
        
        return created_events
    
    @staticmethod
    @transaction.atomic
    def create_hold(room_type, start_date, end_date, hold_count, expires_at, hold_type='MANUAL_HOLD', reference_id=None, notes=''):
        """
        Create temporary inventory hold for a date range.
        """
        # Check availability first
        is_available = InventoryService.check_availability(
            room_type=room_type,
            start_date=start_date,
            end_date=end_date,
            quantity=hold_count
        )
        
        if not is_available:
            raise InsufficientInventoryException("Insufficient inventory to create hold")
        
        current_date = start_date
        created_holds = []
        
        while current_date < end_date:
            hold = InventoryHold.objects.create(
                property=room_type.property,
                room_type=room_type,
                stay_date=current_date,
                hold_count=hold_count,
                hold_type=hold_type,
                expires_at=expires_at,
                reference_id=reference_id,
                notes=notes
            )
            created_holds.append(hold)
            
            # Update inventory held_count
            InventoryCalendar.objects.filter(
                room_type=room_type,
                stay_date=current_date
            ).update(
                held_count=F('held_count') + hold_count,
                version=F('version') + 1
            )
            
            current_date += timedelta(days=1)
            
        return created_holds

    @staticmethod
    @transaction.atomic
    def release_hold(hold):
        """
        Release a single inventory hold.
        """
        if hold.released_at:
            return  # Already released
            
        hold.released_at = datetime.utcnow()
        hold.save()
        
        # Update inventory held_count
        InventoryCalendar.objects.filter(
            room_type=hold.room_type,
            stay_date=hold.stay_date
        ).update(
            held_count=F('held_count') - hold.hold_count,
            version=F('version') + 1
        )

    @staticmethod
    def rebuild_from_events(room_type, date):
        """
        Rebuild inventory calendar from event log (Event Sourcing).
        Used for data recovery or consistency checks.
        
        Args:
            room_type: RoomType instance
            date: datetime.date
            
        Returns:
            InventoryCalendar instance with correct state
        """
        # Get all events for this room_type and date
        events = InventoryEvent.objects.filter(
            room_type=room_type,
            stay_date=date
        ).order_by('created_at')
        
        # Calculate state from events
        physical_count = room_type.base_physical_count
        sold_count = 0
        
        for event in events:
            event_data = event.event_data or {}
            if event.event_type == 'PRELOADED':
                # Initial state
                physical_count = event_data.get('physical_count', room_type.base_physical_count)
            elif event.event_type == 'RESERVED':
                sold_count += event_data.get('quantity', 0)
            elif event.event_type == 'RELEASED':
                sold_count -= event_data.get('quantity', 0)  # Release decreases sold count
            elif event.event_type == 'ADJUSTED':
                # Adjusted events contain the changes made
                if 'physical_count' in event_data.get('changes', {}):
                    physical_count = event_data['changes']['physical_count']
        
        # Update or create inventory record
        inventory, created = InventoryCalendar.objects.update_or_create(
            room_type=room_type,
            stay_date=date,
            defaults={
                'physical_count': physical_count,
                'sold_count': max(0, sold_count),  # Ensure non-negative
                'version': events.count()
            }
        )
        
        return inventory
    
    @staticmethod
    @transaction.atomic
    def bulk_initialize(room_type, start_date, end_date, physical_count, overbooking_limit=0, user=None):
        """
        Bulk initialize inventory for a date range.
        
        Args:
            room_type: RoomType instance
            start_date: datetime.date
            end_date: datetime.date (exclusive)
            physical_count: int - total physical units
            overbooking_limit: int - overbooking allowed
            user: User instance (optional)
            
        Returns:
            int - number of records created
        """
        records_to_create = []
        events_to_create = []
        current_date = start_date
        correlation_id = uuid.uuid4()
        
        while current_date < end_date:
            # Check if record already exists
            if not InventoryCalendar.objects.filter(
                room_type=room_type,
                stay_date=current_date
            ).exists():
                records_to_create.append(
                    InventoryCalendar(
                        property=room_type.property,
                        room_type=room_type,
                        stay_date=current_date,
                        physical_count=physical_count,
                        sold_count=0,
                        held_count=0,
                        ooo_count=0,
                        overbooking_limit=overbooking_limit,
                        version=1
                    )
                )
                
                # Create event
                events_to_create.append(
                    InventoryEvent(
                        property=room_type.property,
                        room_type=room_type,
                        stay_date=current_date,
                        event_type='PRELOADED',
                        event_data={
                            'physical_count': physical_count,
                            'overbooking_limit': overbooking_limit,
                            'user': str(user.id) if user else None
                        },
                        correlation_id=correlation_id
                    )
                )
            
            current_date += timedelta(days=1)
        
        # Bulk create
        created_count = 0
        if records_to_create:
            InventoryCalendar.objects.bulk_create(records_to_create, ignore_conflicts=True)
            created_count = len(records_to_create)
        
        if events_to_create:
            InventoryEvent.objects.bulk_create(events_to_create, ignore_conflicts=True)
        
        # Publish Kafka event
        try:
            producer = get_producer()
            event = InventoryInitializedEvent(
                room_type_id=str(room_type.id),
                property_id=str(room_type.property.id),
                start_date=str(start_date),
                end_date=str(end_date),
                physical_count=physical_count,
                records_created=created_count,
                performed_by=str(user.id) if user else 'system',
                timestamp=datetime.utcnow().isoformat(),
                correlation_id=str(correlation_id)
            )
            producer.send(
                settings.KAFKA_TOPICS['INVENTORY_INITIALIZED'],
                value=json.dumps(event.to_dict()).encode('utf-8')
            )
        except Exception as e:
            # Log but don't fail the operation
            print(f"Failed to publish Kafka event: {e}")
        
        return created_count
    
    @staticmethod
    @transaction.atomic
    def block_inventory(room_type, stay_date, block_count, reason='Manual block', user=None):
        """
        Block inventory (mark as Out of Order).
        
        Args:
            room_type: RoomType instance
            stay_date: datetime.date
            block_count: int - number of units to block
            reason: str - reason for blocking
            user: User instance (optional)
        """
        max_retries = 3
        for attempt in range(max_retries):
            try:
                inventory = InventoryCalendar.objects.select_for_update().get(
                    room_type=room_type,
                    stay_date=stay_date
                )
                
                current_version = inventory.version
                
                # Update with optimistic locking
                updated = InventoryCalendar.objects.filter(
                    id=inventory.id,
                    version=current_version
                ).update(
                    ooo_count=F('ooo_count') + block_count,
                    version=F('version') + 1
                )
                
                if updated == 0:
                    # Version conflict - retry
                    if attempt == max_retries - 1:
                        raise InventoryLockException("Failed to block inventory after retries")
                    continue
                
                # Create event
                event_correlation_id = uuid.uuid4()
                InventoryEvent.objects.create(
                    property=room_type.property,
                    room_type=room_type,
                    stay_date=stay_date,
                    event_type='OOO_ADDED',
                    event_data={
                        'block_count': block_count,
                        'reason': reason,
                        'user': str(user.id) if user else None
                    },
                    correlation_id=event_correlation_id
                )
                
                # Refresh inventory to get updated counts
                inventory.refresh_from_db()
                
                # Publish Kafka event
                try:
                    producer = get_producer()
                    kafka_event = InventoryBlockedEvent(
                        inventory_id=str(inventory.id),
                        room_type_id=str(room_type.id),
                        property_id=str(room_type.property.id),
                        stay_date=str(stay_date),
                        block_count=block_count,
                        new_available=inventory.available_count,
                        reason=reason,
                        performed_by=str(user.id) if user else 'system',
                        timestamp=datetime.utcnow().isoformat(),
                        correlation_id=str(event_correlation_id)
                    )
                    producer.send(
                        settings.KAFKA_TOPICS['INVENTORY_BLOCKED'],
                        value=json.dumps(kafka_event.to_dict()).encode('utf-8')
                    )
                except Exception as e:
                    print(f"Failed to publish Kafka event: {e}")
                
                break
                
            except InventoryCalendar.DoesNotExist:
                raise ValueError(f"Inventory not found for {room_type} on {stay_date}")
    
    @staticmethod
    @transaction.atomic
    def release_inventory(room_type, stay_date, release_count, user=None):
        """
        Release blocked inventory.
        
        Args:
            room_type: RoomType instance
            stay_date: datetime.date
            release_count: int - number of units to release
            user: User instance (optional)
        """
        max_retries = 3
        for attempt in range(max_retries):
            try:
                inventory = InventoryCalendar.objects.select_for_update().get(
                    room_type=room_type,
                    stay_date=stay_date
                )
                
                current_version = inventory.version
                
                # Validate release count
                if inventory.ooo_count < release_count:
                    raise ValueError(f"Cannot release {release_count} units, only {inventory.ooo_count} blocked")
                
                # Update with optimistic locking
                updated = InventoryCalendar.objects.filter(
                    id=inventory.id,
                    version=current_version
                ).update(
                    ooo_count=F('ooo_count') - release_count,
                    version=F('version') + 1
                )
                
                if updated == 0:
                    # Version conflict - retry
                    if attempt == max_retries - 1:
                        raise InventoryLockException("Failed to release inventory after retries")
                    continue
                
                # Create event
                event_correlation_id = uuid.uuid4()
                InventoryEvent.objects.create(
                    property=room_type.property,
                    room_type=room_type,
                    stay_date=stay_date,
                    event_type='OOO_REMOVED',
                    event_data={
                        'release_count': release_count,
                        'user': str(user.id) if user else None
                    },
                    correlation_id=event_correlation_id
                )
                
                # Refresh inventory to get updated counts
                inventory.refresh_from_db()
                
                # Publish Kafka event
                try:
                    producer = get_producer()
                    kafka_event = InventoryReleasedEvent(
                        inventory_id=str(inventory.id),
                        room_type_id=str(room_type.id),
                        property_id=str(room_type.property.id),
                        stay_date=str(stay_date),
                        release_count=release_count,
                        new_available=inventory.available_count,
                        reason='OOO Released',
                        performed_by=str(user.id) if user else 'system',
                        timestamp=datetime.utcnow().isoformat(),
                        correlation_id=str(event_correlation_id)
                    )
                    producer.send(
                        settings.KAFKA_TOPICS['INVENTORY_RELEASED'],
                        value=json.dumps(kafka_event.to_dict()).encode('utf-8')
                    )
                except Exception as e:
                    print(f"Failed to publish Kafka event: {e}")
                
                break
                
            except InventoryCalendar.DoesNotExist:
                raise ValueError(f"Inventory not found for {room_type} on {stay_date}")
    
    @staticmethod
    @transaction.atomic
    def adjust_inventory(room_type, stay_date, physical_count=None, overbooking_limit=None, reason='Manual adjustment', user=None):
        """
        Manually adjust inventory counts.
        
        Args:
            room_type: RoomType instance
            stay_date: datetime.date
            physical_count: int - new physical count (optional)
            overbooking_limit: int - new overbooking limit (optional)
            reason: str - reason for adjustment
            user: User instance (optional)
        """
        max_retries = 3
        for attempt in range(max_retries):
            try:
                inventory = InventoryCalendar.objects.select_for_update().get(
                    room_type=room_type,
                    stay_date=stay_date
                )
                
                current_version = inventory.version
                
                # Prepare update fields
                update_fields = {'version': F('version') + 1}
                changes = {}
                
                if physical_count is not None:
                    update_fields['physical_count'] = physical_count
                    changes['physical_count'] = physical_count
                
                if overbooking_limit is not None:
                    update_fields['overbooking_limit'] = overbooking_limit
                    changes['overbooking_limit'] = overbooking_limit
                
                if not changes:
                    return  # Nothing to update
                
                # Update with optimistic locking
                updated = InventoryCalendar.objects.filter(
                    id=inventory.id,
                    version=current_version
                ).update(**update_fields)
                
                if updated == 0:
                    # Version conflict - retry
                    if attempt == max_retries - 1:
                        raise InventoryLockException("Failed to adjust inventory after retries")
                    continue
                
                # Create event
                event_correlation_id = uuid.uuid4()
                InventoryEvent.objects.create(
                    property=room_type.property,
                    room_type=room_type,
                    stay_date=stay_date,
                    event_type='ADJUSTED',
                    event_data={
                        'changes': changes,
                        'reason': reason,
                        'user': str(user.id) if user else None
                    },
                    correlation_id=event_correlation_id
                )
                
                # Refresh inventory to get updated counts
                inventory.refresh_from_db()
                
                # Publish Kafka event
                try:
                    producer = get_producer()
                    kafka_event = InventoryAdjustedEvent(
                        inventory_id=str(inventory.id),
                        room_type_id=str(room_type.id),
                        property_id=str(room_type.property.id),
                        stay_date=str(stay_date),
                        adjustments=changes,
                        new_available=inventory.available_count,
                        reason=reason,
                        performed_by=str(user.id) if user else 'system',
                        timestamp=datetime.utcnow().isoformat(),
                        correlation_id=str(event_correlation_id)
                    )
                    producer.send(
                        settings.KAFKA_TOPICS['INVENTORY_ADJUSTED'],
                        value=json.dumps(kafka_event.to_dict()).encode('utf-8')
                    )
                except Exception as e:
                    print(f"Failed to publish Kafka event: {e}")
                
                break
                
            except InventoryCalendar.DoesNotExist:
                raise ValueError(f"Inventory not found for {room_type} on {stay_date}")


