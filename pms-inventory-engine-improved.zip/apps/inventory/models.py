from django.db import models
from django.db.models import F
from typing import TYPE_CHECKING
from apps.common.models import UUIDModel, TimeStampedModel
from apps.properties.models import Property, RoomType

if TYPE_CHECKING:
    from builtins import property as property_decorator
else:
    property_decorator = property


class InventoryStatus(models.TextChoices):
    AVAILABLE = 'AVAILABLE', 'Available'
    LIMITED = 'LIMITED', 'Limited'
    SOLD_OUT = 'SOLD_OUT', 'Sold Out'
    CLOSED = 'CLOSED', 'Closed'


class AllotmentType(models.TextChoices):
    ELASTIC = 'ELASTIC', 'Elastic'
    NON_ELASTIC = 'NON_ELASTIC', 'Non-Elastic'
    COMMITTED = 'COMMITTED', 'Committed'
    TENTATIVE = 'TENTATIVE', 'Tentative'


class InventoryCalendar(UUIDModel, TimeStampedModel):
    property = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='inventory',
        db_column='property_id'
    )
    room_type = models.ForeignKey(
        RoomType, 
        on_delete=models.CASCADE,
        related_name='inventory_calendar',
        db_column='room_type_id'
    )
    stay_date = models.DateField(db_index=True)
    physical_count = models.PositiveIntegerField(
        help_text='Total physical units available'
    )
    sold_count = models.PositiveIntegerField(
        default=0,
        help_text='Units sold (confirmed reservations)'
    )
    held_count = models.PositiveIntegerField(
        default=0,
        help_text='Units on temporary hold'
    )
    ooo_count = models.PositiveIntegerField(
        default=0,
        help_text='Out of order units (maintenance, etc.)'
    )
    overbooking_limit = models.PositiveIntegerField(
        default=0,
        help_text='Additional units allowed beyond physical_count'
    )
    
    # Optimistic locking
    version = models.PositiveIntegerField(
        default=1,
        help_text='Version for optimistic locking'
    )
    
    class Meta:
        db_table = 'inventory'
        verbose_name = 'Inventory Calendar'
        verbose_name_plural = 'Inventory Calendar'
        unique_together = ('property', 'room_type', 'stay_date')
        indexes = [
            models.Index(fields=['property', 'room_type', 'stay_date']),
            models.Index(fields=['property', 'stay_date']),
            models.Index(fields=['room_type', 'stay_date', 'version']),
        ]
    
    def __str__(self):
        return f"{self.room_type} - {self.stay_date} (v{self.version})"
    
    @property_decorator
    def available_count(self):
        """
        Calculate available units.
        Formula: physical_count - sold_count - held_count - ooo_count + overbooking_limit
        Guaranteed to be non-negative to prevent logical errors.
        """
        available = (self.physical_count - self.sold_count - 
                    self.held_count - self.ooo_count + self.overbooking_limit)
        return max(0, available)
    
    @property_decorator
    def status(self):
        """Determine inventory status"""
        avail = self.available_count
        if avail <= 0:
            return InventoryStatus.SOLD_OUT
        elif avail <= 3:
            return InventoryStatus.LIMITED
        else:
            return InventoryStatus.AVAILABLE
    
    # Backward compatibility aliases
    @property_decorator
    def date(self):
        return self.stay_date
    
    @property_decorator
    def total_units(self):
        return self.physical_count
    
    @property_decorator
    def booked_units(self):
        return self.sold_count
    
    @property_decorator
    def available_units(self):
        return self.available_count


class InventoryEvent(UUIDModel, TimeStampedModel):
    """
    Immutable event log for all inventory changes.
    Event Sourcing - Single source of truth.
    
    Schema: event_id, inventory_id, property_id, room_type_id, stay_date,
            event_type, event_data, correlation_id, created_at
    """
    EVENT_TYPE_CHOICES = [
        ('PRELOADED', 'Inventory Preloaded'),
        ('RESERVED', 'Units Reserved'),
        ('RELEASED', 'Units Released'),
        ('HELD', 'Units Put on Hold'),
        ('HOLD_RELEASED', 'Hold Released'),
        ('OOO_ADDED', 'Out of Order Added'),
        ('OOO_REMOVED', 'Out of Order Removed'),
        ('ADJUSTED', 'Manual Adjustment'),
    ]
    
    inventory = models.ForeignKey(
        InventoryCalendar,
        on_delete=models.CASCADE,
        related_name='events',
        db_column='inventory_id',
        null=True,
        blank=True
    )
    property = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='inventory_events',
        db_column='property_id'
    )
    room_type = models.ForeignKey(
        RoomType,
        on_delete=models.CASCADE,
        related_name='inventory_events',
        db_column='room_type_id'
    )
    stay_date = models.DateField(db_index=True)
    event_type = models.CharField(max_length=50, choices=EVENT_TYPE_CHOICES)
    event_data = models.JSONField(
        help_text='Event payload with all relevant data'
    )
    correlation_id = models.UUIDField(
        null=True,
        blank=True,
        db_index=True,
        help_text='Links related events (e.g., all events for a reservation)'
    )
    
    class Meta:
        db_table = 'inventory_events'
        verbose_name = 'Inventory Event'
        verbose_name_plural = 'Inventory Events'
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['property', 'room_type', 'stay_date']),
            models.Index(fields=['correlation_id']),
            models.Index(fields=['created_at']),
            models.Index(fields=['event_type', 'created_at']),
        ]
    
    def __str__(self):
        return f"{self.event_type} - {self.room_type} - {self.stay_date}"


class Allotment(UUIDModel, TimeStampedModel):
    """
    Room allotments for contracts/groups.
    
    Schema: allotment_id, property_id, room_type_id, allotment_name, allotment_type,
            start_date, end_date, cutoff_date, total_rooms, picked_up_rooms, status,
            created_at, updated_at
    """
    property = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='allotments',
        db_column='property_id'
    )
    room_type = models.ForeignKey(
        RoomType,
        on_delete=models.CASCADE,
        related_name='allotments',
        db_column='room_type_id'
    )
    allotment_name = models.CharField(max_length=255)
    allotment_type = models.CharField(
        max_length=20,
        choices=AllotmentType.choices,
        default=AllotmentType.ELASTIC
    )
    start_date = models.DateField()
    end_date = models.DateField()
    cutoff_date = models.DateField(
        help_text='Date after which unused allotment is released'
    )
    total_rooms = models.PositiveIntegerField()
    picked_up_rooms = models.PositiveIntegerField(
        default=0,
        help_text='Rooms picked up from allotment'
    )
    status = models.CharField(
        max_length=20,
        default='ACTIVE',
        choices=[
            ('ACTIVE', 'Active'),
            ('EXPIRED', 'Expired'),
            ('CANCELLED', 'Cancelled'),
        ]
    )
    
    class Meta:
        db_table = 'allotments'
        verbose_name = 'Allotment'
        verbose_name_plural = 'Allotments'
        indexes = [
            models.Index(fields=['property', 'room_type']),
            models.Index(fields=['start_date', 'end_date']),
            models.Index(fields=['status']),
        ]
    
    def __str__(self):
        return f"{self.allotment_name} - {self.room_type}"
    
    @property_decorator
    def remaining_rooms(self):
        """Calculate remaining rooms in allotment"""
        return self.total_rooms - self.picked_up_rooms


class InventoryHold(UUIDModel, TimeStampedModel):
    """
    Temporary inventory holds (e.g., for pending bookings).
    
    Schema: hold_id, property_id, room_type_id, stay_date, hold_count, 
            hold_type, expires_at, released_at
    """
    property = models.ForeignKey(
        Property,
        on_delete=models.CASCADE,
        related_name='inventory_holds',
        db_column='property_id'
    )
    room_type = models.ForeignKey(
        RoomType,
        on_delete=models.CASCADE,
        related_name='inventory_holds',
        db_column='room_type_id'
    )
    stay_date = models.DateField(db_index=True)
    hold_count = models.PositiveIntegerField()
    hold_type = models.CharField(
        max_length=50,
        choices=[
            ('BOOKING_CART', 'Booking Cart'),
            ('PENDING_PAYMENT', 'Pending Payment'),
            ('MANUAL_HOLD', 'Manual Hold'),
            ('SYSTEM_HOLD', 'System Hold'),
        ]
    )
    expires_at = models.DateTimeField(
        help_text='When this hold automatically expires'
    )
    released_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text='When this hold was released'
    )
    
    # Additional metadata
    reference_id = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        help_text='Reference to cart/booking/transaction (e.g., cart_abc123, booking_xyz789)'
    )
    notes = models.TextField(blank=True)
    
    class Meta:
        db_table = 'inventory_holds'
        verbose_name = 'Inventory Hold'
        verbose_name_plural = 'Inventory Holds'
        indexes = [
            models.Index(fields=['property', 'room_type', 'stay_date']),
            models.Index(fields=['expires_at']),
            models.Index(fields=['released_at']),
            models.Index(fields=['reference_id']),
        ]
    
    def __str__(self):
        return f"{self.hold_type} - {self.room_type} - {self.stay_date}"
    
    @property_decorator
    def is_active(self):
        """Check if hold is still active"""
        from django.utils import timezone
        return self.released_at is None and self.expires_at > timezone.now()
