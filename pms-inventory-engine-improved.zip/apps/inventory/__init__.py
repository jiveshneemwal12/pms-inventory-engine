"""
Inventory app - CRITICAL: Inventory correctness lives here.
"""
