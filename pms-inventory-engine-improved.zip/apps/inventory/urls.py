from django.urls import path
from . import views

app_name = 'inventory'

urlpatterns = [
    path('check-availability/', views.check_availability, name='check_availability'),
    path('bulk-initialize/', views.bulk_initialize_inventory, name='bulk_initialize'),
    path('block/', views.block_inventory, name='block_inventory'),
    path('release/', views.release_inventory, name='release_inventory'),
    path('adjust/', views.adjust_inventory, name='adjust_inventory'),
    path('calendar/', views.get_availability_calendar, name='availability_calendar'),
    path('events/', views.get_inventory_events, name='inventory_events'),
    
    # Property-level inventory endpoints
    path('property/<uuid:property_id>/', views.get_property_inventory, name='get_property_inventory'),
    path('property/<uuid:property_id>/room-type/<uuid:room_type_id>/', views.get_room_type_inventory, name='get_room_type_inventory'),
    
    # Hold management endpoints
    path('hold/', views.create_hold, name='create_hold'),
    path('hold/<uuid:hold_id>/', views.release_hold, name='release_hold'),
    path('holds/by-reference/<str:reference_id>/', views.release_holds_by_reference, name='release_holds_by_reference'),
    
    # Allotment endpoints
    path('allotments/', views.create_allotment, name='create_allotment'),
    path('allotments/<uuid:allotment_id>/', views.get_allotment, name='get_allotment'),
]
