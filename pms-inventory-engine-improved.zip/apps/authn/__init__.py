"""
Authentication & authorization app.
"""
