"""
Signal handlers for authentication events.
"""
from django.dispatch import receiver
from django_rest_passwordreset.signals import reset_password_token_created

from apps.common.mails import send_html_email
from apps.events.producer import get_producer
from .events import PasswordResetRequestedEvent
import logging

logger = logging.getLogger(__name__)


@receiver(reset_password_token_created)
def password_reset_token_created(sender, instance, reset_password_token, *args, **kwargs):
    """
    Handle password reset token creation.
    Sends email with reset link to user.
    
    Args:
        sender: The sender class
        instance: ViewSet instance that sent the signal
        reset_password_token: The token object
    """
    # Build the password reset URL
    # In production, replace with your frontend URL
    reset_url = f"{instance.request.scheme}://{instance.request.get_host()}/reset-password?token={reset_password_token.key}"
    
    # Prepare email data
    data = {
        'user': reset_password_token.user,
        'first_name': reset_password_token.user.first_name or '',
        'email': reset_password_token.user.email,
        'reset_url': reset_url,
        'token': reset_password_token.key,
    }
    
    # Send HTML email using template
    try:
        send_html_email(
            subject='Password Reset Request - PMS',
            template_name='authn/password_reset_email.html',
            data=data,
            to=[reset_password_token.user.email]
        )
        
        logger.info(f"Password reset email sent to {reset_password_token.user.email}")
        
        # Publish password reset requested event to Kafka
        try:
            from datetime import datetime
            event = PasswordResetRequestedEvent(
                user_id=str(reset_password_token.user.id),
                email=reset_password_token.user.email,
                timestamp=datetime.utcnow().isoformat()
            )
            get_producer().publish('PASSWORD_RESET_REQUESTED', event)
        except Exception as e:
            logger.error(f"Failed to publish password reset requested event: {str(e)}")
        
    except Exception as e:
        logger.error(f"Failed to send password reset email to {reset_password_token.user.email}: {str(e)}")
