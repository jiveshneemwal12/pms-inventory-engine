from typing import cast, Any
from rest_framework import status, generics
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from rest_framework.throttling import ScopedRateThrottle, AnonRateThrottle
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenRefreshView

from apps.common.response import create_response
from apps.common.utils import generate_random_password, send_login_details
from apps.events.producer import get_producer
from .models import User
from .cache import cache_user, get_cached_user_by_email, invalidate_user_cache
from .events import UserRegisteredEvent, UserLoggedInEvent, PasswordChangedEvent
from .serializers import (
    RegisterSerializer,
    LoginSerializer,
    ChangePasswordSerializer,
    SetPasswordSerializer,
    LoginDetailsSerializer
)

import threading
import logging

logger = logging.getLogger(__name__)


class RegisterView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [AnonRateThrottle]
    
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        
        if serializer.is_valid():
            user = cast(User, serializer.save())
            logger.info(f"User {user.email} registered successfully")
            
            # Publish user registered event to Kafka
            try:
                from datetime import datetime
                event = UserRegisteredEvent(
                    user_id=str(user.id),
                    email=user.email,
                    role=user.role,
                    timestamp=datetime.utcnow().isoformat()
                )
                get_producer().publish('USER_REGISTERED', event)
            except Exception as e:
                logger.error(f"Failed to publish user registered event: {str(e)}")
            
            return create_response(
                "success",
                "User registered successfully. Please login to continue.",
                data={'email': user.email},
                http_status=status.HTTP_201_CREATED
            )
        
        return create_response(
            "failed",
            "User registration failed",
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )


class LoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'login'
    
    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')
        
        if not email:
            logger.error("Email is required")
            return create_response(
                'failed',
                'Email is required',
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        if not password:
            logger.error("Password is required")
            return create_response(
                'failed',
                'Password is required',
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        # Try to get user from cache first
        cached_user_data = get_cached_user_by_email(email.lower())
        
        # Always fetch from DB to verify password
        try:
            user = User.objects.get(email=email.lower())
        except User.DoesNotExist:
            return create_response(
                'failed',
                'Invalid credentials',
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        if not user.is_active:
            return create_response(
                'failed',
                'User account is inactive',
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        if user.check_password(password):
            # Cache user data for future requests
            cache_user(user)
            
            refresh = RefreshToken.for_user(user)
            user_data = LoginSerializer(user).data
            
            logger.info(f"User {user.email} logged in successfully")
            
            # Publish user logged in event to Kafka
            try:
                from datetime import datetime
                event = UserLoggedInEvent(
                    user_id=str(user.id),
                    email=user.email,
                    timestamp=datetime.utcnow().isoformat(),
                    ip_address=request.META.get('REMOTE_ADDR')
                )
                get_producer().publish('USER_LOGGED_IN', event)
            except Exception as e:
                logger.error(f"Failed to publish user logged in event: {str(e)}")
            
            return create_response(
                'success',
                'Login successful',
                data={
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'user': user_data,
                }
            )
        
        return create_response(
            'failed',
            'Invalid credentials',
            http_status=status.HTTP_400_BAD_REQUEST
        )


class ChangePasswordView(generics.UpdateAPIView):
    serializer_class = ChangePasswordSerializer
    permission_classes = [IsAuthenticated]
    
    def get_object(self, queryset=None):
        return self.request.user
    
    def update(self, request, *args, **kwargs):
        user = self.get_object()
        serializer = self.get_serializer(data=request.data)
        
        if serializer.is_valid():
            if not user.check_password(serializer.data.get('old_password')):
                return create_response(
                    'failed',
                    'Old password is incorrect',
                    http_status=status.HTTP_400_BAD_REQUEST
                )
            
            user.set_password(serializer.data.get('new_password'))
            user.first_time = False
            user.save()
            
            # Invalidate user cache after password change
            invalidate_user_cache(user)
            
            logger.info(f"Password changed for user {user.email}")
            
            # Publish password changed event to Kafka
            try:
                from datetime import datetime
                event = PasswordChangedEvent(
                    user_id=str(user.id),
                    email=user.email,
                    changed_by='self',
                    timestamp=datetime.utcnow().isoformat()
                )
                get_producer().publish('PASSWORD_CHANGED', event)
            except Exception as e:
                logger.error(f"Failed to publish password changed event: {str(e)}")
            
            return create_response(
                'success',
                'Password updated successfully'
            )
        
        return create_response(
            'failed',
            'Password update failed',
            errors=serializer.errors,
            http_status=status.HTTP_400_BAD_REQUEST
        )


class SetPasswordForUserView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        if request.user.role not in ['SUPER_ADMIN']:
            return create_response(
                'failed',
                'You are not authorized to perform this action',
                http_status=status.HTTP_403_FORBIDDEN
            )
        
        serializer = SetPasswordSerializer(data=request.data)
        
        if not serializer.is_valid():
            return create_response(
                'failed',
                'Invalid request',
                errors=serializer.errors,
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        validated_data = cast(dict[str, Any], serializer.validated_data)
        user_id = validated_data['user_id']
        
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return create_response(
                'failed',
                'User not found',
                http_status=status.HTTP_404_NOT_FOUND
            )
        
        if not user.is_active:
            return create_response(
                'failed',
                'User account is inactive',
                http_status=status.HTTP_400_BAD_REQUEST
            )
        
        password = generate_random_password()
        user.set_password(password)
        user.first_time = True
        user.save()
        
        # Invalidate user cache after password reset
        invalidate_user_cache(user)
        
        # Publish password changed event to Kafka
        try:
            from datetime import datetime
            event = PasswordChangedEvent(
                user_id=str(user.id),
                email=user.email,
                changed_by=request.user.email,
                timestamp=datetime.utcnow().isoformat()
            )
            get_producer().publish('PASSWORD_CHANGED', event)
        except Exception as e:
            logger.error(f"Failed to publish password changed event: {str(e)}")
        
        thread = threading.Thread(
            target=send_login_details,
            args=(LoginDetailsSerializer(user).data, password)
        )
        thread.start()
        
        logger.info(f"Password set for user {user.email} by admin {request.user.email}")
        
        return create_response(
            'success',
            'Password set successfully. Login details sent to user email.',
            data={'user_id': str(user.id)}
        )
