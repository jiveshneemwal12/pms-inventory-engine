"""
Event schemas for authentication events.
"""
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Optional


@dataclass
class UserRegisteredEvent:
    """Event published when a new user registers"""
    event_type: str = "user.registered"
    user_id: str = ""
    email: str = ""
    role: str = ""
    timestamp: str = ""
    
    def to_dict(self):
        return asdict(self)


@dataclass
class UserLoggedInEvent:
    """Event published when a user logs in"""
    event_type: str = "user.logged_in"
    user_id: str = ""
    email: str = ""
    timestamp: str = ""
    ip_address: Optional[str] = None
    
    def to_dict(self):
        return asdict(self)


@dataclass
class PasswordChangedEvent:
    """Event published when a user changes password"""
    event_type: str = "user.password_changed"
    user_id: str = ""
    email: str = ""
    changed_by: str = ""  # 'self' or admin_email
    timestamp: str = ""
    
    def to_dict(self):
        return asdict(self)


@dataclass
class PasswordResetRequestedEvent:
    """Event published when a user requests password reset"""
    event_type: str = "user.password_reset_requested"
    user_id: str = ""
    email: str = ""
    timestamp: str = ""
    
    def to_dict(self):
        return asdict(self)
