"""
Cache utilities for user authentication.
"""
from django.core.cache import cache
from django.conf import settings
from typing import Optional
import logging

logger = logging.getLogger(__name__)

# Cache TTL settings
USER_CACHE_TTL = 1800  # 30 minutes
USER_EMAIL_CACHE_TTL = 900  # 15 minutes


def get_user_cache_key(user_id: str) -> str:
    """Generate cache key for user by ID"""
    return f"user:{user_id}"


def get_user_email_cache_key(email: str) -> str:
    """Generate cache key for user by email"""
    return f"user:email:{email.lower()}"


def cache_user(user) -> None:
    """
    Cache user data by both ID and email.
    
    Args:
        user: User model instance
    """
    try:
        user_data = {
            'id': str(user.id),
            'email': user.email,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'role': user.role,
            'mobile_number': user.mobile_number,
            'is_active': user.is_active,
            'first_time': user.first_time,
        }
        
        # Cache by user ID (longer TTL)
        cache.set(get_user_cache_key(str(user.id)), user_data, USER_CACHE_TTL)
        
        # Cache by email for quick login lookup (shorter TTL)
        cache.set(get_user_email_cache_key(user.email), user_data, USER_EMAIL_CACHE_TTL)
        
        logger.debug(f"Cached user data for {user.email}")
    except Exception as e:
        logger.error(f"Failed to cache user {user.email}: {str(e)}")


def get_cached_user_by_email(email: str) -> Optional[dict]:
    """
    Get user data from cache by email.
    
    Args:
        email: User email
        
    Returns:
        User data dict or None
    """
    try:
        cached_data = cache.get(get_user_email_cache_key(email))
        if cached_data:
            logger.debug(f"Cache hit for user email: {email}")
            return cached_data
        logger.debug(f"Cache miss for user email: {email}")
        return None
    except Exception as e:
        logger.error(f"Failed to get cached user by email {email}: {str(e)}")
        return None


def get_cached_user_by_id(user_id: str) -> Optional[dict]:
    """
    Get user data from cache by ID.
    
    Args:
        user_id: User UUID
        
    Returns:
        User data dict or None
    """
    try:
        cached_data = cache.get(get_user_cache_key(user_id))
        if cached_data:
            logger.debug(f"Cache hit for user ID: {user_id}")
            return cached_data
        logger.debug(f"Cache miss for user ID: {user_id}")
        return None
    except Exception as e:
        logger.error(f"Failed to get cached user by ID {user_id}: {str(e)}")
        return None


def invalidate_user_cache(user) -> None:
    """
    Invalidate all cache entries for a user.
    Call this when user data changes (password change, profile update, etc.)
    
    Args:
        user: User model instance or dict with id and email
    """
    try:
        user_id = str(user.id) if hasattr(user, 'id') else str(user.get('id'))
        email = user.email if hasattr(user, 'email') else user.get('email')
        
        cache.delete(get_user_cache_key(user_id))
        cache.delete(get_user_email_cache_key(email))
        
        logger.info(f"Invalidated cache for user: {email}")
    except Exception as e:
        logger.error(f"Failed to invalidate user cache: {str(e)}")
