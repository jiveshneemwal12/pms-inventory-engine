"""
Rate plan and daily rate calendar models.
"""
from django.db import models
from apps.common.models import UUIDModel, TimeStampedModel
from apps.properties.models import RoomType


class RatePlan(UUIDModel, TimeStampedModel):
    """
    Rate plan for a room type.
    """
    room_type = models.ForeignKey(
        RoomType, 
        on_delete=models.CASCADE,
        related_name='rate_plans'
    )
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        db_table = 'rate_plans'
        verbose_name = 'Rate Plan'
        verbose_name_plural = 'Rate Plans'
    
    def __str__(self):
        return f"{self.room_type} - {self.name}"


class DailyRate(UUIDModel):
    """
    Daily rate calendar for a rate plan.
    """
    rate_plan = models.ForeignKey(
        RatePlan,
        on_delete=models.CASCADE,
        related_name='daily_rates'
    )
    date = models.DateField(db_index=True)
    base_rate = models.DecimalField(
        max_digits=10, 
        decimal_places=2,
        help_text='Base nightly rate'
    )
    
    class Meta:
        db_table = 'daily_rates'
        verbose_name = 'Daily Rate'
        verbose_name_plural = 'Daily Rates'
        unique_together = ('rate_plan', 'date')
        indexes = [
            models.Index(fields=['rate_plan', 'date']),
        ]
    
    def __str__(self):
        return f"{self.rate_plan} - {self.date}: ${self.base_rate}"
