from django.contrib import admin
from .models import RatePlan, DailyRate


@admin.register(RatePlan)
class RatePlanAdmin(admin.ModelAdmin):
    list_display = ('name', 'room_type', 'is_active', 'created_at')
    list_filter = ('is_active', 'room_type')
    search_fields = ('name', 'room_type__name')


@admin.register(DailyRate)
class DailyRateAdmin(admin.ModelAdmin):
    list_display = ('rate_plan', 'date', 'base_rate')
    list_filter = ('rate_plan', 'date')
    search_fields = ('rate_plan__name',)
    date_hierarchy = 'date'
