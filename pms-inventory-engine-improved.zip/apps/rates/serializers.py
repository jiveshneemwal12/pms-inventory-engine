"""
Serializers for rates.
"""
from rest_framework import serializers
from .models import RatePlan, DailyRate


class RatePlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = RatePlan
        fields = ('id', 'room_type', 'name', 'description', 'is_active', 'created_at', 'updated_at')
        read_only_fields = ('id', 'created_at', 'updated_at')


class DailyRateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DailyRate
        fields = ('id', 'rate_plan', 'date', 'base_rate')
        read_only_fields = ('id',)
