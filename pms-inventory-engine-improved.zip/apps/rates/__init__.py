"""
Rates app - Pricing only.
"""
